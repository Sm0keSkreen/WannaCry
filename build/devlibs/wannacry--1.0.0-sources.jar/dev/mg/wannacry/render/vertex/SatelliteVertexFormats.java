package dev.mg.wannacry.render.vertex;

import com.mojang.blaze3d.vertex.VertexFormat;

public abstract class SatelliteVertexFormats {

    public static final VertexFormat POS2 = VertexFormat.builder()
        .add("Position", SatelliteVertexFormatElements.POS2)
        .build();

    private SatelliteVertexFormats() {}
}
