package dev.mg.wannacry.event.impl.entity;

import dev.mg.wannacry.event.Event;
import net.minecraft.world.entity.LivingEntity;

public class DeathEvent extends Event {
    private final LivingEntity entity;

    public DeathEvent(LivingEntity entity) {
        this.entity = entity;
    }

    public LivingEntity getEntity() {
        return entity;
    }
}
