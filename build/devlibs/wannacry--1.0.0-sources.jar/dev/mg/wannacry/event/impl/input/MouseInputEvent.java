package dev.mg.wannacry.event.impl.input;

import dev.mg.wannacry.event.Event;

public class MouseInputEvent extends Event {
    private final int button;
    private final int action;

    public MouseInputEvent(int button, int action) {
        this.button = button;
        this.action = action;
    }

    public int getButton() {
        return button;
    }

    public int getAction() {
        return action;
    }
}

