package dev.mg.wannacry.render.postprocess;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.buffers.Std140Builder;
import com.mojang.blaze3d.buffers.Std140SizeCalculator;
import java.nio.ByteBuffer;
import net.minecraft.class_11280;

public class OutlineUniforms {
    private static final int SIZE = new Std140SizeCalculator()
        .putInt()
        .putFloat()
        .putInt()
        .putFloat()
        .get();

    private static final class_11280<Data> STORAGE =
        new class_11280<>("Satellite - Outline UBO", SIZE, 16);

    private OutlineUniforms() {}

    public static GpuBufferSlice write(int width, float fillOpacity, int shapeMode, float glowMultiplier) {
        return STORAGE.method_71102(new Data(width, fillOpacity, shapeMode, glowMultiplier));
    }

    public static void flipFrame() {
        STORAGE.method_71100();
    }

    private record Data(int width, float fillOpacity, int shapeMode, float glowMultiplier)
        implements class_11280.class_11281 {
        @Override
        public void method_71104(ByteBuffer buf) {
            Std140Builder.intoBuffer(buf)
                .putInt(width)
                .putFloat(fillOpacity)
                .putInt(shapeMode)
                .putFloat(glowMultiplier);
        }
    }
}
