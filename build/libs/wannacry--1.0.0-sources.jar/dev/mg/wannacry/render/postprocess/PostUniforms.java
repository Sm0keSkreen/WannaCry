package dev.mg.wannacry.render.postprocess;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.buffers.Std140Builder;
import com.mojang.blaze3d.buffers.Std140SizeCalculator;
import java.nio.ByteBuffer;
import net.minecraft.class_11280;

public class PostUniforms {
    private static final int SIZE = new Std140SizeCalculator()
        .putVec2()
        .putFloat()
        .get();

    private static final class_11280<Data> STORAGE =
        new class_11280<>("Satellite - Post UBO", SIZE, 16);

    private PostUniforms() {}

    public static GpuBufferSlice write(float sizeX, float sizeY, float time) {
        return STORAGE.method_71102(new Data(sizeX, sizeY, time));
    }

    public static void flipFrame() {
        STORAGE.method_71100();
    }

    private record Data(float sizeX, float sizeY, float time)
        implements class_11280.class_11281 {
        @Override
        public void method_71104(ByteBuffer buf) {
            Std140Builder.intoBuffer(buf)
                .putVec2(sizeX, sizeY)
                .putFloat(time);
        }
    }
}
