package dev.mg.wannacry.render.postprocess;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import dev.mg.wannacry.render.SatelliteFullscreenQuad;
import dev.mg.wannacry.render.SatelliteRenderPipelines;
import java.util.OptionalInt;
import net.minecraft.class_11658;
import net.minecraft.class_276;
import net.minecraft.class_4587;
import net.minecraft.class_6367;

import static org.lwjgl.glfw.GLFW.glfwGetTime;
import static dev.mg.wannacry.util.traits.Util.mc;

public class SatelliteShaderESP {
    public static final SatelliteShaderESP INSTANCE = new SatelliteShaderESP();

    public class_276 framebuffer;

    private SatelliteShaderESP() {}

    public void init() {
        framebuffer = new class_6367(
            "Satellite ShaderESP",
            mc.method_22683().method_4489(),
            mc.method_22683().method_4506(),
            true
        );
    }

    public void beginRender() {

    }

    public void draw(class_11658 levelState, class_4587 matrices) {

    }

    public void drawBlocks(class_4587 matrices) {

    }

    public void render() {

    }

    public void onResized(int width, int height) {
        if (framebuffer != null) framebuffer.method_1234(width, height);
    }

    @Deprecated
    public void submitVertices() {}
}
