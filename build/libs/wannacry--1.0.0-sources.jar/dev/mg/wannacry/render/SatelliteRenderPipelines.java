package dev.mg.wannacry.render;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import dev.mg.wannacry.Satellite;
import dev.mg.wannacry.render.vertex.SatelliteVertexFormats;
import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_10789;
import net.minecraft.class_2960;
import net.minecraft.class_3300;

public abstract class SatelliteRenderPipelines {
    private static final List<RenderPipeline> PIPELINES = new ArrayList<>();

    public static final RenderPipeline POST_OUTLINE = add(
        RenderPipeline.builder()
            .withLocation(class_2960.method_60655("wannacry", "pipeline/post/outline"))
            .withVertexFormat(SatelliteVertexFormats.POS2, VertexFormat.class_5596.field_27379)
            .withVertexShader(class_2960.method_60655("wannacry", "shaders/post-process/base.vsh"))
            .withFragmentShader(class_2960.method_60655("wannacry", "shaders/post-process/outline.fsh"))
            .withSampler("u_Texture")
            .withUniform("PostData", class_10789.field_60031)
            .withUniform("OutlineData", class_10789.field_60031)
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .withDepthWrite(false)
            .withBlend(BlendFunction.TRANSLUCENT)
            .withCull(false)
            .build()
    );

    private static RenderPipeline add(RenderPipeline pipeline) {
        PIPELINES.add(pipeline);
        return pipeline;
    }

    public static void precompile(class_3300 resources) {
        GpuDevice device = RenderSystem.getDevice();
        if (device == null) {
            Satellite.LOGGER.warn("[Satellite] precompile() called before GpuDevice is ready; skipping");
            return;
        }

        for (RenderPipeline pipeline : PIPELINES) {
            device.precompilePipeline(pipeline, (identifier, stage) -> {
                Optional<net.minecraft.class_3298> opt =
                        resources.method_14486(identifier);
                if (opt.isEmpty()) {

                    throw new RuntimeException(
                        "[Satellite] Shader not found in ResourceManager: " + identifier
                            + " — ensure the satellite JAR is a loaded resource pack.");
                }
                try (var in = opt.get().method_14482()) {
                    return IOUtils.toString(in, StandardCharsets.UTF_8);
                } catch (IOException e) {
                    throw new RuntimeException(
                        "[Satellite] Failed to read shader source: " + identifier, e);
                }
            });
        }
        Satellite.LOGGER.info("[Satellite] Shader pipelines precompiled successfully");
    }

    private SatelliteRenderPipelines() {}
}
