package dev.mg.wannacry.render;

import net.minecraft.class_1921;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_9799;

public class CustomOutlineVertexConsumerProvider implements class_4597 {
    private final class_4597.class_4598 immediate =
        class_4597.method_22991(new class_9799(1536));

    @Override
    public class_4588 method_73477(class_1921 layer) {
        if (layer.method_24295()) {
            return new PassthroughVertexConsumer(immediate.method_73477(layer));
        }
        var outline = layer.method_23289();
        if (outline.isPresent()) {
            return new PassthroughVertexConsumer(immediate.method_73477(outline.get()));
        }
        return NoopVertexConsumer.INSTANCE;
    }

    public void draw() {
        immediate.method_22993();
    }

    private record PassthroughVertexConsumer(class_4588 delegate) implements class_4588 {
        @Override public class_4588 method_22912(float x, float y, float z) { delegate.method_22912(x, y, z); return this; }
        @Override public class_4588 method_1336(int r, int g, int b, int a) { delegate.method_1336(r, g, b, a); return this; }
        @Override public class_4588 method_39415(int argb) { delegate.method_39415(argb); return this; }
        @Override public class_4588 method_22913(float u, float v) { delegate.method_22913(u, v); return this; }
        @Override public class_4588 method_60796(int u, int v) { return this; }
        @Override public class_4588 method_22921(int u, int v) { return this; }
        @Override public class_4588 method_22914(float x, float y, float z) { return this; }
        @Override public class_4588 method_75298(float width) { return this; }
    }
}
