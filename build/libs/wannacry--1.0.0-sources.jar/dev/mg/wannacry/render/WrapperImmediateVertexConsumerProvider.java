package dev.mg.wannacry.render;

import java.util.function.Supplier;
import net.minecraft.class_1921;
import net.minecraft.class_4588;
import net.minecraft.class_4597;

public class WrapperImmediateVertexConsumerProvider extends class_4597.class_4598 {
    private final Supplier<class_4597> supplier;

    public WrapperImmediateVertexConsumerProvider(Supplier<class_4597> supplier) {
        super(null, null);
        this.supplier = supplier;
    }

    @Override
    public class_4588 method_73477(class_1921 layer) {
        return supplier.get().method_73477(layer);
    }

    @Override public void method_22993() {}
    @Override public void method_22994(class_1921 layer) {}
}
