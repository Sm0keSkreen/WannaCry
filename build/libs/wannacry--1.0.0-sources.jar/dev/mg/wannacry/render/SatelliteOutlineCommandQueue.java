package dev.mg.wannacry.render;

import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;

import java.util.List;
import net.minecraft.class_10017;
import net.minecraft.class_10444;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_11661;
import net.minecraft.class_11683;
import net.minecraft.class_11788;
import net.minecraft.class_11791;
import net.minecraft.class_12075;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_3879;
import net.minecraft.class_4587;
import net.minecraft.class_5481;
import net.minecraft.class_630;
import net.minecraft.class_777;
import net.minecraft.class_811;

public class SatelliteOutlineCommandQueue extends class_11661 {
    private int color;
    private int[] tints;

    public void setColor(int argb) {
        this.color = argb;
    }

    @Override
    public class_11788 method_73529(int i) {
        return field_62244.computeIfAbsent(i, key -> new OutlineBatch(this));
    }

    private class OutlineBatch extends class_11788 {
        OutlineBatch(class_11661 parent) {
            super(parent);
        }

        @Override
        public void method_73479(class_4587 ps, float r,
                                 List<class_10017.class_11680> pieces) {}

        @Override
        public void method_73482(class_4587 ps, @Nullable class_243 v, int i,
                                  class_2561 c, boolean b, int j, double d,
                                  class_12075 cam) {}

        @Override
        public void method_73478(class_4587 ps, float x, float y,
                               class_5481 seq, boolean ds,
                               class_327.class_6415 dm, int l, int col,
                               int bg, int ol) {}

        @Override
        public void method_73488(class_4587 ps, class_10017 state,
                                Quaternionf q) {}

        @Override
        public void method_73486(class_4587 ps,
                                class_10017.class_10018 ls) {}

        @Override
        public void method_73485(class_4587 ps,
                                      class_11791 state) {}

        public void submitBreakingBlockModel(class_4587 ps,
                                             class_1087 m,
                                             long seed, int prog) {}

        @Override
        public void method_73483(class_4587 ps, class_1921 rt,
                                         class_11660 r) {}

        @Override
        public void method_74315(class_11947 r) {}

        @Override
        public <S> void method_73490(class_3879<? super S> model, S state,
                                    class_4587 matrices, class_1921 layer,
                                    int light, int overlay, int tintedColor,
                                    @Nullable class_1058 sprite,
                                    int outlineColor,
                                    @Nullable class_11683.class_11792 crumble) {
            super.method_73490(model, state, matrices, layer,
                              light, overlay, color, sprite, 0, crumble);
        }

        @Override
        public void method_73494(class_630 part, class_4587 matrices,
                                    class_1921 layer, int light, int overlay,
                                    @Nullable class_1058 sprite,
                                    boolean sheeted, boolean hasGlint,
                                    int tintedColor,
                                    @Nullable class_11683.class_11792 crumble,
                                    int i) {
            super.method_73494(part, matrices, layer,
                                  light, overlay, sprite,
                                  sheeted, hasGlint, color, crumble, i);
        }

        @Override
        public void method_73484(class_4587 ps, class_1921 rt,
                                     class_1087 model,
                                     float r, float g, float b,
                                     int light, int overlay, int outlineColor) {
            float cr = ((color >> 16) & 0xFF) / 255f;
            float cg = ((color >> 8)  & 0xFF) / 255f;
            float cb = ( color        & 0xFF) / 255f;
            super.method_73484(ps, rt, model, cr, cg, cb, light, overlay, outlineColor);
        }

        @Override
        public void method_73480(class_4587 ps, class_811 ctx,
                               int light, int overlay, int outlineColor,
                               int[] tintLayers, List<class_777> quads,
                               class_1921 renderType,
                               class_10444.class_10445 foilType) {
            if (tints == null || tints[0] != color) {
                tints = new int[]{color, color, color, color};
            }
            super.method_73480(ps, ctx, light, overlay,
                             outlineColor, tints, quads, renderType, foilType);
        }
    }
}
