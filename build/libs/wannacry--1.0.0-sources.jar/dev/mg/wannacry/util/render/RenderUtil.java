package dev.mg.wannacry.util.render;

import com.mojang.blaze3d.vertex.*;
import dev.mg.wannacry.util.render.state.RectRenderState;
import dev.mg.wannacry.util.traits.Util;
import org.joml.Matrix3x2f;

import java.awt.*;
import net.minecraft.class_10799;
import net.minecraft.class_11231;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_332;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_7833;

public class RenderUtil implements Util {

    public static void rect(class_332 context, float x1, float y1, float x2, float y2, int color) {
        int ix1 = Math.round(x1);
        int iy1 = Math.round(y1);
        int ix2 = Math.round(x2);
        int iy2 = Math.round(y2);
        context.method_25294(ix1, iy1, ix2, iy2, color);
    }

    public static void rect(class_332 context, float x1, float y1, float x2, float y2, int color, float width) {
        int w = Math.max(1, Math.round(width));
        context.method_25294(Math.round(x1), Math.round(y1), Math.round(x2), Math.round(y1) + w, color);
        context.method_25294(Math.round(x2) - w, Math.round(y1), Math.round(x2), Math.round(y2), color);
        context.method_25294(Math.round(x1), Math.round(y2) - w, Math.round(x2), Math.round(y2), color);
        context.method_25294(Math.round(x1), Math.round(y1), Math.round(x1) + w, Math.round(y2), color);
    }

    public static void horizontalGradient(class_332 context, float x1, float y1, float x2, float y2, Color left, Color right) {
        int ix1 = Math.round(x1);
        int iy1 = Math.round(y1);
        int ix2 = Math.round(x2);
        int iy2 = Math.round(y2);

        gradient(context, ix1, iy1, ix2, iy2, left.hashCode(), left.hashCode(), right.hashCode(), right.hashCode());
    }

    public static void verticalGradient(class_332 context, float x1, float y1, float x2, float y2, Color top, Color bottom) {
        int ix1 = Math.round(x1);
        int iy1 = Math.round(y1);
        int ix2 = Math.round(x2);
        int iy2 = Math.round(y2);

        gradient(context, ix1, iy1, ix2, iy2, top.hashCode(), bottom.hashCode(), bottom.hashCode(), top.hashCode());
    }

    public static void gradient(class_332 graphics,
                                int x1, int y1, int x2, int y2,
                                int topLeft, int bottomLeft, int bottomRight, int topRight) {
        graphics.field_59826.method_70919(new RectRenderState(
                class_10799.field_56879, class_11231.method_70899(), new Matrix3x2f(graphics.method_51448()),
                x1, y1, x2, y2,
                topLeft, bottomLeft, bottomRight, topRight,
                graphics.field_44659.method_70863()
        ));
    }

    public static void rect(class_4587 stack, float x1, float y1, float x2, float y2, int color) {
        rectFilled(stack, x1, y1, x2, y2, color);
    }

    public static void rect(class_4587 stack, float x1, float y1, float x2, float y2, int color, float width) {
        drawHorizontalLine(stack, x1, x2, y1, color, width);
        drawVerticalLine(stack, x2, y1, y2, color, width);
        drawHorizontalLine(stack, x1, x2, y2, color, width);
        drawVerticalLine(stack, x1, y1, y2, color, width);
    }

    protected static void drawHorizontalLine(class_4587 matrices, float x1, float x2, float y, int color) {
        if (x2 < x1) {
            float i = x1;
            x1 = x2;
            x2 = i;
        }

        rectFilled(matrices, x1, y, x2 + 1, y + 1, color);
    }

    protected static void drawVerticalLine(class_4587 matrices, float x, float y1, float y2, int color) {
        if (y2 < y1) {
            float i = y1;
            y1 = y2;
            y2 = i;
        }

        rectFilled(matrices, x, y1 + 1, x + 1, y2, color);
    }

    protected static void drawHorizontalLine(class_4587 matrices, float x1, float x2, float y, int color, float width) {
        if (x2 < x1) {
            float i = x1;
            x1 = x2;
            x2 = i;
        }

        rectFilled(matrices, x1, y, x2 + width, y + width, color);
    }

    protected static void drawVerticalLine(class_4587 matrices, float x, float y1, float y2, int color, float width) {
        if (y2 < y1) {
            float i = y1;
            y1 = y2;
            y2 = i;
        }

        rectFilled(matrices, x, y1 + width, x + width, y2, color);
    }

    public static void rectFilled(class_4587 matrix, float x1, float y1, float x2, float y2, int color) {
        float i;
        if (x1 < x2) {
            i = x1;
            x1 = x2;
            x2 = i;
        }

        if (y1 < y2) {
            i = y1;
            y1 = y2;
            y2 = i;
        }

        float f = (float) (color >> 24 & 255) / 255.0F;
        float g = (float) (color >> 16 & 255) / 255.0F;
        float h = (float) (color >> 8 & 255) / 255.0F;
        float j = (float) (color & 255) / 255.0F;

        class_287 bufferBuilder = class_289.method_1348()
                .method_60827(VertexFormat.class_5596.field_27382, class_290.field_1576);
        bufferBuilder.method_22918(matrix.method_23760().method_23761(), x1, y2, 0.0F).method_22915(g, h, j, f);
        bufferBuilder.method_22918(matrix.method_23760().method_23761(), x2, y2, 0.0F).method_22915(g, h, j, f);
        bufferBuilder.method_22918(matrix.method_23760().method_23761(), x2, y1, 0.0F).method_22915(g, h, j, f);
        bufferBuilder.method_22918(matrix.method_23760().method_23761(), x1, y1, 0.0F).method_22915(g, h, j, f);

        Layers.quads().method_60895(bufferBuilder.method_60800());
    }

    public static void horizontalGradient(class_4587 matrix, float x1, float y1, float x2, float y2, Color left, Color right) {
        class_287 bufferBuilder = class_289.method_1348()
                .method_60827(VertexFormat.class_5596.field_27382, class_290.field_1576);
        bufferBuilder.method_22918(matrix.method_23760().method_23761(), x1, y1, 0.0F).method_22915(left.getRed() / 255.0F, left.getGreen() / 255.0F, left.getBlue() / 255.0F, left.getAlpha() / 255.0F);
        bufferBuilder.method_22918(matrix.method_23760().method_23761(), x1, y2, 0.0F).method_22915(left.getRed() / 255.0F, left.getGreen() / 255.0F, left.getBlue() / 255.0F, left.getAlpha() / 255.0F);
        bufferBuilder.method_22918(matrix.method_23760().method_23761(), x2, y2, 0.0F).method_22915(right.getRed() / 255.0F, right.getGreen() / 255.0F, right.getBlue() / 255.0F, right.getAlpha() / 255.0F);
        bufferBuilder.method_22918(matrix.method_23760().method_23761(), x2, y1, 0.0F).method_22915(right.getRed() / 255.0F, right.getGreen() / 255.0F, right.getBlue() / 255.0F, right.getAlpha() / 255.0F);

        Layers.quads().method_60895(bufferBuilder.method_60800());
    }

    public static void verticalGradient(class_4587 matrix, float x1, float y1, float x2, float y2, Color top, Color bottom) {
        class_287 bufferBuilder = class_289.method_1348()
                .method_60827(VertexFormat.class_5596.field_27382, class_290.field_1576);
        bufferBuilder.method_22918(matrix.method_23760().method_23761(), x1, y1, 0.0F).method_22915(top.getRed() / 255.0F, top.getGreen() / 255.0F, top.getBlue() / 255.0F, top.getAlpha() / 255.0F);
        bufferBuilder.method_22918(matrix.method_23760().method_23761(), x1, y2, 0.0F).method_22915(bottom.getRed() / 255.0F, bottom.getGreen() / 255.0F, bottom.getBlue() / 255.0F, bottom.getAlpha() / 255.0F);
        bufferBuilder.method_22918(matrix.method_23760().method_23761(), x2, y2, 0.0F).method_22915(bottom.getRed() / 255.0F, bottom.getGreen() / 255.0F, bottom.getBlue() / 255.0F, bottom.getAlpha() / 255.0F);
        bufferBuilder.method_22918(matrix.method_23760().method_23761(), x2, y1, 0.0F).method_22915(top.getRed() / 255.0F, top.getGreen() / 255.0F, top.getBlue() / 255.0F, top.getAlpha() / 255.0F);

        Layers.quads().method_60895(bufferBuilder.method_60800());
    }

    public static void drawBoxFilled(class_4587 stack, class_238 box, Color c) {
        float minX = (float) (box.field_1323 - mc.method_1561().field_4686.method_71156().method_10216());
        float minY = (float) (box.field_1322 - mc.method_1561().field_4686.method_71156().method_10214());
        float minZ = (float) (box.field_1321 - mc.method_1561().field_4686.method_71156().method_10215());
        float maxX = (float) (box.field_1320 - mc.method_1561().field_4686.method_71156().method_10216());
        float maxY = (float) (box.field_1325 - mc.method_1561().field_4686.method_71156().method_10214());
        float maxZ = (float) (box.field_1324 - mc.method_1561().field_4686.method_71156().method_10215());

        class_287 bufferBuilder = class_289.method_1348()
                .method_60827(VertexFormat.class_5596.field_27382, class_290.field_1576);
        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, minY, minZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, minY, minZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, minY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, minY, maxZ).method_39415(c.getRGB());

        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, maxY, minZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, maxY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, maxY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, maxY, minZ).method_39415(c.getRGB());

        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, minY, minZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, maxY, minZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, maxY, minZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, minY, minZ).method_39415(c.getRGB());

        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, minY, minZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, maxY, minZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, maxY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, minY, maxZ).method_39415(c.getRGB());

        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, minY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, minY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, maxY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, maxY, maxZ).method_39415(c.getRGB());

        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, minY, minZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, minY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, maxY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, maxY, minZ).method_39415(c.getRGB());

        Layers.quads().method_60895(bufferBuilder.method_60800());
    }

    public static void drawBoxFilled(class_4587 stack, class_243 vec, Color c) {
        drawBoxFilled(stack, class_238.method_29968(vec), c);
    }

    public static void drawBoxFilled(class_4587 stack, class_2338 bp, Color c) {
        drawBoxFilled(stack, new class_238(bp), c);
    }

    public static void drawBoxFilledGradient(class_4587 stack, class_238 box,
                                             Color bottomColor, Color topColor) {
        float minX = (float) (box.field_1323 - mc.method_1561().field_4686.method_71156().method_10216());
        float minY = (float) (box.field_1322 - mc.method_1561().field_4686.method_71156().method_10214());
        float minZ = (float) (box.field_1321 - mc.method_1561().field_4686.method_71156().method_10215());
        float maxX = (float) (box.field_1320 - mc.method_1561().field_4686.method_71156().method_10216());
        float maxY = (float) (box.field_1325 - mc.method_1561().field_4686.method_71156().method_10214());
        float maxZ = (float) (box.field_1324 - mc.method_1561().field_4686.method_71156().method_10215());

        int botC = bottomColor.getRGB();
        int topC = topColor.getRGB();

        class_287 buf = class_289.method_1348()
                .method_60827(VertexFormat.class_5596.field_27382, class_290.field_1576);

        buf.method_22918(stack.method_23760().method_23761(), minX, minY, minZ).method_39415(botC);
        buf.method_22918(stack.method_23760().method_23761(), maxX, minY, minZ).method_39415(botC);
        buf.method_22918(stack.method_23760().method_23761(), maxX, minY, maxZ).method_39415(botC);
        buf.method_22918(stack.method_23760().method_23761(), minX, minY, maxZ).method_39415(botC);

        buf.method_22918(stack.method_23760().method_23761(), minX, maxY, minZ).method_39415(topC);
        buf.method_22918(stack.method_23760().method_23761(), minX, maxY, maxZ).method_39415(topC);
        buf.method_22918(stack.method_23760().method_23761(), maxX, maxY, maxZ).method_39415(topC);
        buf.method_22918(stack.method_23760().method_23761(), maxX, maxY, minZ).method_39415(topC);

        buf.method_22918(stack.method_23760().method_23761(), minX, minY, minZ).method_39415(botC);
        buf.method_22918(stack.method_23760().method_23761(), minX, maxY, minZ).method_39415(topC);
        buf.method_22918(stack.method_23760().method_23761(), maxX, maxY, minZ).method_39415(topC);
        buf.method_22918(stack.method_23760().method_23761(), maxX, minY, minZ).method_39415(botC);

        buf.method_22918(stack.method_23760().method_23761(), maxX, minY, maxZ).method_39415(botC);
        buf.method_22918(stack.method_23760().method_23761(), maxX, maxY, maxZ).method_39415(topC);
        buf.method_22918(stack.method_23760().method_23761(), minX, maxY, maxZ).method_39415(topC);
        buf.method_22918(stack.method_23760().method_23761(), minX, minY, maxZ).method_39415(botC);

        buf.method_22918(stack.method_23760().method_23761(), maxX, minY, minZ).method_39415(botC);
        buf.method_22918(stack.method_23760().method_23761(), maxX, maxY, minZ).method_39415(topC);
        buf.method_22918(stack.method_23760().method_23761(), maxX, maxY, maxZ).method_39415(topC);
        buf.method_22918(stack.method_23760().method_23761(), maxX, minY, maxZ).method_39415(botC);

        buf.method_22918(stack.method_23760().method_23761(), minX, minY, maxZ).method_39415(botC);
        buf.method_22918(stack.method_23760().method_23761(), minX, maxY, maxZ).method_39415(topC);
        buf.method_22918(stack.method_23760().method_23761(), minX, maxY, minZ).method_39415(topC);
        buf.method_22918(stack.method_23760().method_23761(), minX, minY, minZ).method_39415(botC);

        Layers.quads().method_60895(buf.method_60800());
    }

    public static void drawBox(class_4587 stack, class_238 box, Color c, float lineWidth) {
        drawBoxAABB(stack, box, c.getRGB(), c.getRGB(), lineWidth);
    }

    public static void drawBox(class_4587 stack, class_265 shape, Color c, float lineWidth) {
        class_243 camera = mc.method_1561().field_4686.method_71156();

        class_287 bufferBuilder = class_289.method_1348()
                .method_60827(VertexFormat.class_5596.field_27377, class_290.field_63455);
        class_4587.class_4665 pose = stack.method_23760();
        int color = c.getRGB();

        shape.method_1104((x1, y1, z1, x2, y2, z2) -> {
            addLine(bufferBuilder, pose, color, lineWidth,
                    x1 - camera.field_1352, y1 - camera.field_1351, z1 - camera.field_1350,
                    x2 - camera.field_1352, y2 - camera.field_1351, z2 - camera.field_1350
            );
        });

        Layers.lines().method_60895(bufferBuilder.method_60800());
    }

    private static void drawBoxAABB(class_4587 stack, class_238 box, int botC, int topC, float lineWidth) {
        class_243 camera = mc.method_1561().field_4686.method_71156();
        float x0 = (float) (box.field_1323 - camera.field_1352);
        float y0 = (float) (box.field_1322 - camera.field_1351);
        float z0 = (float) (box.field_1321 - camera.field_1350);
        float x1 = (float) (box.field_1320 - camera.field_1352);
        float y1 = (float) (box.field_1325 - camera.field_1351);
        float z1 = (float) (box.field_1324 - camera.field_1350);

        class_287 buf = class_289.method_1348()
                .method_60827(VertexFormat.class_5596.field_27377, class_290.field_63455);
        class_4587.class_4665 pose = stack.method_23760();

        addLineColored(buf, pose, lineWidth, x0, y0, z0, x1, y0, z0, botC, botC);
        addLineColored(buf, pose, lineWidth, x1, y0, z0, x1, y0, z1, botC, botC);
        addLineColored(buf, pose, lineWidth, x1, y0, z1, x0, y0, z1, botC, botC);
        addLineColored(buf, pose, lineWidth, x0, y0, z1, x0, y0, z0, botC, botC);

        addLineColored(buf, pose, lineWidth, x0, y1, z0, x1, y1, z0, topC, topC);
        addLineColored(buf, pose, lineWidth, x1, y1, z0, x1, y1, z1, topC, topC);
        addLineColored(buf, pose, lineWidth, x1, y1, z1, x0, y1, z1, topC, topC);
        addLineColored(buf, pose, lineWidth, x0, y1, z1, x0, y1, z0, topC, topC);

        addLineColored(buf, pose, lineWidth, x0, y0, z0, x0, y1, z0, botC, topC);
        addLineColored(buf, pose, lineWidth, x1, y0, z0, x1, y1, z0, botC, topC);
        addLineColored(buf, pose, lineWidth, x1, y0, z1, x1, y1, z1, botC, topC);
        addLineColored(buf, pose, lineWidth, x0, y0, z1, x0, y1, z1, botC, topC);

        Layers.lines().method_60895(buf.method_60800());

        if (lineWidth > 1.5f) {
            float eps = 0.001f;
            class_287 pts = class_289.method_1348()
                    .method_60827(VertexFormat.class_5596.field_27377, class_290.field_63455);

            addLineColored(pts, pose, lineWidth, x0, y0, z0, x0 + eps, y0, z0, botC, botC);
            addLineColored(pts, pose, lineWidth, x1, y0, z0, x1 + eps, y0, z0, botC, botC);
            addLineColored(pts, pose, lineWidth, x1, y0, z1, x1 + eps, y0, z1, botC, botC);
            addLineColored(pts, pose, lineWidth, x0, y0, z1, x0 + eps, y0, z1, botC, botC);

            addLineColored(pts, pose, lineWidth, x0, y1, z0, x0 + eps, y1, z0, topC, topC);
            addLineColored(pts, pose, lineWidth, x1, y1, z0, x1 + eps, y1, z0, topC, topC);
            addLineColored(pts, pose, lineWidth, x1, y1, z1, x1 + eps, y1, z1, topC, topC);
            addLineColored(pts, pose, lineWidth, x0, y1, z1, x0 + eps, y1, z1, topC, topC);
            Layers.lines().method_60895(pts.method_60800());
        }
    }

    private static void addLine(class_287 buf, class_4587.class_4665 pose, int color, float lineWidth,
                                double x1, double y1, double z1, double x2, double y2, double z2) {
        float dx = (float) (x2 - x1);
        float dy = (float) (y2 - y1);
        float dz = (float) (z2 - z1);
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1e-6f) len = 1f;
        float nx = dx / len;
        float ny = dy / len;
        float nz = dz / len;

        buf.method_56824(pose, (float) x1, (float) y1, (float) z1)
                .method_39415(color).method_22914(nx, ny, nz).method_75298(lineWidth);
        buf.method_56824(pose, (float) x2, (float) y2, (float) z2)
                .method_39415(color).method_22914(nx, ny, nz).method_75298(lineWidth);
    }

    private static void addLineColored(class_287 buf, class_4587.class_4665 pose, float lineWidth,
                                       float x1, float y1, float z1, float x2, float y2, float z2,
                                       int color1, int color2) {
        float dx = x2 - x1;
        float dy = y2 - y1;
        float dz = z2 - z1;
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1e-6f) len = 1f;
        float nx = dx / len;
        float ny = dy / len;
        float nz = dz / len;

        buf.method_56824(pose, x1, y1, z1).method_39415(color1).method_22914(nx, ny, nz).method_75298(lineWidth);
        buf.method_56824(pose, x2, y2, z2).method_39415(color2).method_22914(nx, ny, nz).method_75298(lineWidth);
    }

    public static void drawBoxGradient(class_4587 stack, class_238 box,
                                       Color bottomColor, Color topColor, float lineWidth) {
        drawBoxAABB(stack, box, bottomColor.getRGB(), topColor.getRGB(), lineWidth);
    }

    public static void drawLine(class_4587 stack,
                                class_243 start, class_243 end,
                                int colorStart, int colorEnd,
                                float lineWidth) {
        class_243 camera = mc.method_1561().field_4686.method_71156();

        float x1 = (float) (start.field_1352 - camera.field_1352);
        float y1 = (float) (start.field_1351 - camera.field_1351);
        float z1 = (float) (start.field_1350 - camera.field_1350);
        float x2 = (float) (end.field_1352   - camera.field_1352);
        float y2 = (float) (end.field_1351   - camera.field_1351);
        float z2 = (float) (end.field_1350   - camera.field_1350);

        float dx = x2 - x1;
        float dy = y2 - y1;
        float dz = z2 - z1;
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1e-6f) return;
        float nx = dx / len;
        float ny = dy / len;
        float nz = dz / len;

        class_287 buf = class_289.method_1348()
                .method_60827(VertexFormat.class_5596.field_27377, class_290.field_63455);
        class_4587.class_4665 pose = stack.method_23760();
        buf.method_56824(pose, x1, y1, z1).method_39415(colorStart).method_22914(nx, ny, nz).method_75298(lineWidth);
        buf.method_56824(pose, x2, y2, z2).method_39415(colorEnd).method_22914(nx, ny, nz).method_75298(lineWidth);
        Layers.lines().method_60895(buf.method_60800());
    }

    public static void drawLine(class_4587 stack,
                                class_243 start, class_243 end,
                                Color color, float lineWidth) {
        drawLine(stack, start, end, color.getRGB(), color.getRGB(), lineWidth);
    }

    public static void drawBox(class_4587 stack, class_243 vec, Color c, float lineWidth) {
        drawBox(stack, class_238.method_29968(vec), c, lineWidth);
    }

    public static void drawBox(class_4587 stack, class_2338 bp, Color c, float lineWidth) {
        drawBox(stack, new class_238(bp), c, lineWidth);
    }

    public static class_4587 matrixFrom(class_243 pos) {
        class_4587 matrices = new class_4587();
        class_4184 camera = mc.field_1773.method_19418();
        matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
        matrices.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0F));
        matrices.method_22904(pos.method_10216() - camera.method_71156().field_1352, pos.method_10214() - camera.method_71156().field_1351, pos.method_10215() - camera.method_71156().field_1350);
        return matrices;
    }
}
