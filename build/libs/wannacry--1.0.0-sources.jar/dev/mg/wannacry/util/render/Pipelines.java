package dev.mg.wannacry.util.render;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.class_290;
import net.minecraft.class_2960;

import static net.minecraft.class_10799.*;

class Pipelines {
    static final RenderPipeline.Snippet GLOBAL_LINES_SNIPPET = RenderPipeline.builder(field_60127, field_60126)
            .withVertexShader(class_2960.method_60655("wannacry", "core/rendertype_lines_smooth"))
            .withFragmentShader(class_2960.method_60655("wannacry", "core/rendertype_lines_smooth"))
            .withVertexFormat(class_290.field_63455, VertexFormat.class_5596.field_27377)
            .withBlend(BlendFunction.TRANSLUCENT)
            .withCull(false)
            .buildSnippet();

    static final RenderPipeline GLOBAL_QUADS_PIPELINE = RenderPipeline.builder(field_56860)
            .withLocation("pipeline/global_fill_pipeline")
            .withVertexFormat(class_290.field_1576, VertexFormat.class_5596.field_27382)
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .withBlend(BlendFunction.TRANSLUCENT)
            .withDepthWrite(false)
            .withCull(false)
            .build();

    static final RenderPipeline GLOBAL_LINES_PIPELINE = RenderPipeline.builder(GLOBAL_LINES_SNIPPET)
            .withLocation("pipeline/global_lines_pipeline")
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .withDepthWrite(false)
            .build();
}
