package dev.mg.wannacry.util;

import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_9334;

public final class ShieldUtils {

    private ShieldUtils() {}

    public static boolean isShielding(class_1657 target) {
        if (!target.method_6115()) return false;

        class_1268 hand = target.method_6058();
        class_1799 stack = target.method_5998(hand);
        if (stack.method_7960()) return false;

        if (stack.method_58694(class_9334.field_56396) == null) return false;

        return isFacingUs(target);
    }

    public static boolean isShieldingAny(class_1657 target) {
        if (!target.method_6115()) return false;
        class_1268 hand = target.method_6058();
        class_1799 stack = target.method_5998(hand);
        if (stack.method_7960()) return false;
        return stack.method_58694(class_9334.field_56396) != null;
    }

    public static boolean isFacingUs(class_1657 target) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return false;

        class_243 targetToUs = mc.field_1724.method_73189().method_1020(target.method_73189());
        double len = targetToUs.method_1033();
        if (len < 1e-6) return true;
        targetToUs = targetToUs.method_1021(1.0 / len);

        double yawRad = Math.toRadians(target.method_36454());
        double fwdX = -Math.sin(yawRad);
        double fwdZ =  Math.cos(yawRad);

        double dot = fwdX * targetToUs.field_1352 + fwdZ * targetToUs.field_1350;
        return dot > 0.0;
    }
}
