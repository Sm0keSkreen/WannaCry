package dev.mg.wannacry.util;

import dev.mg.wannacry.features.settings.Bind;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_11908;
import net.minecraft.class_3675;

public class KeyboardUtil {
    public static String getKeyName(int key, boolean mouse) {
        return getKeyName(mouse ? Bind.mouse(key) : Bind.keyboard(key));
    }

    public static String getKeyName(Bind bind) {
        if (bind.isEmpty()) return "NONE";
        if (bind.isMouse()) return "MOUSE" + (-bind.getKey() - 1);
        return getKeyName(class_3675.method_15985(new class_11908(bind.getKey(), 0, 0)));
    }

    public static String getKeyName(class_3675.class_306 key) {
        return key.method_1441()
                .replace("key.mouse.", "")
                .replace("key.keyboard.", "")
                .replace(".", "_")
                .toUpperCase(Locale.ROOT);
    }

    public static Bind getBind(String name) {
        String lowercaseName = name.toLowerCase(Locale.ROOT).replace("_", ".");
        if (name.startsWith("mouse")) {
            try {
                return new Bind(-Integer.parseInt(name.substring(5)) - 1);
            } catch (Exception e) {
                return null;
            }
        }

        try {
            class_3675.class_306 key = class_3675.method_15981("key.keyboard." + lowercaseName);
            return new Bind(key.method_1444());
        } catch (IllegalArgumentException exception) {
            return null;
        }
    }

    public static Iterable<String> iterateKeys() {
        List<String> keys = new ArrayList<>();
        for (class_3675.class_306 key : class_3675.class_307.field_1668.field_1674.values())
            keys.add(getKeyName(key));
        for (int i = 1; i <= 9; i++) {
            keys.add("MOUSE" + i);
        }
        return keys;
    }
}
