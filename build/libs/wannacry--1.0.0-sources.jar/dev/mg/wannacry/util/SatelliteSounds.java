package dev.mg.wannacry.util;

import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

public final class SatelliteSounds {

    public static class_3414 UI_CLICK;

    private SatelliteSounds() {}

    public static void register() {
        UI_CLICK = registerEvent("wannacry", "ui_click");
    }

    private static class_3414 registerEvent(String namespace, String path) {
        class_2960 id = class_2960.method_60655(namespace, path);
        class_3414 event = class_3414.method_47908(id);
        class_2378.method_10230(class_7923.field_41172, id, event);
        return event;
    }
}
