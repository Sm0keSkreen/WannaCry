package dev.mg.wannacry.util.traits;

import dev.mg.wannacry.event.system.EventBus;
import net.minecraft.class_310;

public interface Util {
    class_310 mc = class_310.method_1551();
    EventBus EVENT_BUS = new EventBus();

    static boolean isLocalPlayer(Object o) {
        return o == mc.field_1724;
    }
}
