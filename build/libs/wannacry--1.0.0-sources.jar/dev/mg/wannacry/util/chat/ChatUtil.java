package dev.mg.wannacry.util.chat;

import dev.mg.wannacry.Satellite;
import dev.mg.wannacry.ducks.render.IChatComponent;
import dev.mg.wannacry.features.commands.Command;
import dev.mg.wannacry.util.TextUtil;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_303;
import net.minecraft.class_5250;
import net.minecraft.class_7469;
import net.minecraft.class_7591;

import static dev.mg.wannacry.util.traits.Util.mc;

public class ChatUtil {
    public static class_5250 prefix() {
        return withPrefix((class_2561) null);
    }

    public static class_5250 withPrefix(String string) {
        return withPrefix(string, new Object[0]);
    }

    public static class_5250 withPrefix(String string, Object... o) {
        return withPrefix(TextUtil.text(string, o));
    }

    public static class_5250 withPrefix(class_2561 component) {
        class_5250 text = class_2561.method_43473()
                .method_10862(class_2583.field_24360.method_10977(class_124.field_1080))
                .method_10852(class_2561.method_43470("<"))
                .method_10852(getClientNameComponent())
                .method_10852(class_2561.method_43470(">"));
        if (component != null) text.method_27693(" ").method_10852(component);
        return text;
    }

    public static void sendMessage(class_2561 message, Signature identifier) {
        sendClientSideMessage(withPrefix(message), identifier);
    }

    public static void sendClientSideMessage(class_2561 message, Signature sig) {
        if (Command.nullCheck()) return;

        IChatComponent chat = (IChatComponent) mc.field_1705.method_1743();
        class_7469 signature = new class_7469(sig.getByteSignature());
        chat.satellite$removeMessage(signature);
        chat.satellite$addMessage(new class_303(mc.field_1705.method_1738(), message, signature, getMessageTag()));
    }

    public static class_2561 getClientNameComponent() {
        return class_2561.method_43473().method_54663(Satellite.colorManager.getColorAsInt()).method_27693("WannaCry");
    }

    private static class_7591 getMessageTag() {
        return new class_7591(Satellite.colorManager.getColorAsInt(), null, null, null);
    }
}
