package dev.mg.wannacry.util.models;

import dev.mg.wannacry.util.MathUtil;
import net.minecraft.class_1297;
import net.minecraft.class_243;

import static dev.mg.wannacry.util.traits.Util.mc;

public record Angles(float yRot, float xRot) {
    public Angles(float[] rot) {
        this(rot[0], rot[1]);
    }

    public static Angles pos(class_243 pos) {
        return new Angles(MathUtil.calcAngle(mc.field_1724.method_33571(), pos));
    }

    public static Angles entity(class_1297 entity) {
        return pos(MathUtil.clamp(mc.field_1724.method_33571(), entity.method_5829()));
    }
}
