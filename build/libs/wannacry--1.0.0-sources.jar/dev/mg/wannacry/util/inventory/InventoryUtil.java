package dev.mg.wannacry.util.inventory;

import dev.mg.wannacry.util.inventory.strategy.HoldingStrategy;
import dev.mg.wannacry.util.inventory.strategy.HotbarStrategy;
import dev.mg.wannacry.util.inventory.strategy.InventoryStrategy;
import dev.mg.wannacry.util.inventory.strategy.SwapStrategy;
import dev.mg.wannacry.util.traits.Util;
import java.util.EnumSet;
import java.util.List;
import java.util.function.BiPredicate;
import java.util.function.Consumer;
import java.util.function.Predicate;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;

public final class InventoryUtil implements Util {
    static final Result NONE = new Result(-1, class_1799.field_8037, ResultType.NONE);

    public static final EnumSet<ResultType> HOTBAR_SCOPE = EnumSet.of(ResultType.OFFHAND, ResultType.HOTBAR);
    public static final EnumSet<ResultType> INVENTORY_SCOPE = EnumSet.of(ResultType.OFFHAND, ResultType.INVENTORY);
    public static final EnumSet<ResultType> FULL_SCOPE = EnumSet.of(ResultType.OFFHAND, ResultType.HOTBAR, ResultType.INVENTORY);

    private static final List<SwapStrategy> STRATEGIES = List.of(
            HoldingStrategy.INSTANCE,
            HotbarStrategy.INSTANCE,
            InventoryStrategy.INSTANCE
    );

    private InventoryUtil() {
        throw new AssertionError();
    }

    public static class_1799 cursor() {
        return mc.field_1724.field_7512.method_34255();
    }

    public static int selected() {
        return mc.field_1724.method_31548().method_67532();
    }

    public static void click(int slot, int button, class_1713 type) {
        int id = mc.field_1724.field_7512.field_7763;
        mc.field_1761.method_2906(id, slot, button, type, mc.field_1724);
    }

    public static void withSwap(Result result, Runnable action) {
        withSwap(result, r -> action.run());
    }

    public static void withSwap(Result result, Consumer<Result> action) {
        int lastSlot = selected();
        if (InventoryUtil.swap(result)) {
            action.accept(result);
            InventoryUtil.swapBack(result, lastSlot);
        }
    }

    public static void swap(int to) {
        if (to < 0 || to > 8) return;
        mc.field_1724.method_31548().method_61496(to);
        mc.field_1761.method_2911();
    }

    public static boolean swap(Result result) {
        for (SwapStrategy strategy : STRATEGIES) {
            if (strategy.swap(result))
                return true;
        }
        return false;
    }

    public static boolean swapBack(Result result, int last) {
        for (SwapStrategy strategy : STRATEGIES) {
            if (strategy.swapBack(last, result))
                return true;
        }
        return false;
    }

    public static Result find(class_1792 target, EnumSet<ResultType> scopes) {
        return find(stack -> stack.method_31574(target), scopes);
    }

    public static Result find(Predicate<class_1799> predicate, EnumSet<ResultType> scopes) {
        return find((item, scope) -> scopes.contains(scope) && predicate.test(item));
    }

    public static Result find(BiPredicate<class_1799, ResultType> predicate) {
        class_1799 offhand = mc.field_1724.method_6079();
        if (predicate.test(offhand, ResultType.OFFHAND)) {
            return Result.fromOffhand(offhand);
        }

        for (int i = 0; i < 36; i++) {
            class_1799 item = mc.field_1724.method_31548().method_5438(i);
            ResultType type = i < 9 ? ResultType.HOTBAR : ResultType.INVENTORY;
            if (predicate.test(item, type)) {
                return new Result(i, item, type);
            }
        }

        return NONE;
    }
}
