package dev.mg.wannacry.util;

import dev.mg.wannacry.util.traits.Util;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1292;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1303;
import net.minecraft.class_1304;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1683;
import net.minecraft.class_1799;
import net.minecraft.class_1893;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_2680;
import net.minecraft.class_2846;
import net.minecraft.class_2879;
import net.minecraft.class_3486;
import net.minecraft.class_3965;

public class InteractionUtil implements Util {
    public static boolean canBreak(class_2338 blockPos, class_2680 state) {
        if (!mc.field_1724.method_68878() && state.method_26214(mc.field_1687, blockPos) < 0) return false;
        return state.method_26218(mc.field_1687, blockPos) != class_259.method_1073();
    }

    public static boolean isPlaceable(class_2338 pos, boolean entityCheck) {
        if (!mc.field_1687.method_8320(pos).method_45474()) return false;
        for (class_1297 e : mc.field_1687.method_8390(class_1297.class, new class_238(pos), e -> !(e instanceof class_1683 || e instanceof class_1542 || e instanceof class_1303))) {
            if (e instanceof class_1657) return false;
            return !entityCheck;
        }
        return true;
    }

    public static boolean breakBlock(class_2338 pos) {
        if (!canBreak(pos, mc.field_1687.method_8320(pos))) return false;
        class_2338 bp = pos instanceof class_2338.class_2339 ? new class_2338(pos) : pos;

        mc.method_1562().method_52787(new class_2846(class_2846.class_2847.field_12968, bp, class_2350.field_11036));
        mc.field_1724.method_6104(class_1268.field_5808);
        mc.method_1562().method_52787(new class_2846(class_2846.class_2847.field_12973, bp, class_2350.field_11036));

        mc.method_1562().method_52787(new class_2879(class_1268.field_5808));

        return true;
    }

    public static void useItem(class_2338 pos) {
        useItem(pos, class_1268.field_5808);
    }

    public static void useItem(class_2338 pos, class_1268 hand) {
        if (mc.field_1687 == null || mc.field_1724 == null || mc.field_1761 == null) return;
        class_2350 direction = mc.field_1765 != null ? ((class_3965) mc.field_1765).method_17780() : class_2350.field_11033;
        class_1269 result = mc.field_1761.method_2896(mc.field_1724, hand, new class_3965(
                class_243.method_24953(pos), direction, pos, false
        ));
        if (result instanceof class_1269.class_9860 success && success.comp_2909() != class_1269.class_9861.field_52426) {
            mc.field_1724.field_3944.method_52787(new class_2879(hand));
        }
    }

    public static boolean place(class_2338 pos, boolean airPlace) {
        return place(pos, airPlace, class_1268.field_5808);
    }

    public static boolean place(class_2338 pos, boolean airPlace, class_1268 hand) {
        if (mc.field_1687 == null || mc.field_1724 == null || mc.field_1761 == null) return false;
        if (!isPlaceable(pos, false)) return false;
        class_2350 direction = calcSide(pos);
        if (direction == null) {
            if (airPlace)
                direction = mc.field_1765 != null ? ((class_3965) mc.field_1765).method_17780() : class_2350.field_11033;
            else return false;
        }
        class_2338 bp = airPlace ? pos : pos.method_10093(direction);
        class_1269 result = mc.field_1761.method_2896(mc.field_1724, hand, new class_3965(
                airPlace ? class_243.method_24953(pos) : class_243.method_24953(bp).method_43206(direction.method_10153(), 0.5),
                airPlace ? direction : direction.method_10153(), bp, false
        ));
        if (result instanceof class_1269.class_9860 success && success.comp_2909() != class_1269.class_9861.field_52426) {
            mc.field_1724.field_3944.method_52787(new class_2879(hand));
        }
        return true;
    }

    public static class_2350 calcSide(class_2338 pos) {
        for (class_2350 d : class_2350.values())
            if (!mc.field_1687.method_8320(pos.method_10081(d.method_62675())).method_45474()) return d;
        return null;
    }

    public static double getBlockBreakingSpeed(int slot, class_2338 pos) {
        return getBlockBreakingSpeed(slot, mc.field_1687.method_8320(pos));
    }

    public static double getBlockBreakingSpeed(int slot, class_2680 block) {
        double speed = mc.field_1724.method_31548().method_67533().get(slot).method_7924(block);

        if (speed > 1) {
            class_1799 tool = mc.field_1724.method_31548().method_5438(slot);

            int efficiency = EnchantmentUtil.getLevel(class_1893.field_9131, tool);

            if (efficiency > 0 && !tool.method_7960()) speed += efficiency * efficiency + 1;
        }

        if (class_1292.method_5576(mc.field_1724)) {
            speed *= 1 + (class_1292.method_5575(mc.field_1724) + 1) * 0.2F;
        }

        if (mc.field_1724.method_6059(class_1294.field_5901)) {
            float k = switch (mc.field_1724.method_6112(class_1294.field_5901).method_5578()) {
                case 0 -> 0.3F;
                case 1 -> 0.09F;
                case 2 -> 0.0027F;
                default -> 8.1E-4F;
            };

            speed *= k;
        }

        if (mc.field_1724.method_5777(class_3486.field_15517) && EnchantmentUtil.has(class_1893.field_9105, class_1304.field_6169)) {
            speed /= 5.0F;
        }

        if (!mc.field_1724.method_24828()) {
            speed /= 5.0F;
        }

        float hardness = block.method_26214(null, null);
        if (hardness == -1) return 0;

        speed /= hardness / (!block.method_29291() || mc.field_1724.method_31548().method_67533().get(slot).method_7951(block) ? 30 : 100);

        float ticks = (float) (Math.floor(1.0f / speed) + 1.0f);

        return (long) ((ticks / 20.0f) * 1000);
    }

    public static class_2350 right(class_2350 direction) {
        return switch (direction) {
            case field_11034 -> class_2350.field_11035;
            case field_11035 -> class_2350.field_11039;
            case field_11039 -> class_2350.field_11043;
            case field_11043 -> class_2350.field_11034;
            default -> throw new IllegalStateException("Unexpected value: " + direction);
        };
    }

    public static class_2350 left(class_2350 direction) {
        return switch (direction) {
            case field_11034 -> class_2350.field_11043;
            case field_11043 -> class_2350.field_11039;
            case field_11039 -> class_2350.field_11035;
            case field_11035 -> class_2350.field_11034;
            default -> throw new IllegalStateException("Unexpected value: " + direction);
        };
    }
}
