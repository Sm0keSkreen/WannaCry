package dev.mg.wannacry.event.impl.render;

import dev.mg.wannacry.event.Event;
import net.minecraft.class_332;

public class Render2DEvent extends Event {
    private final class_332 context;
    private final float delta;

    public Render2DEvent(class_332 context, float delta) {
        this.context = context;
        this.delta = delta;
    }

    public class_332 getContext() {
        return context;
    }

    public float getDelta() {
        return delta;
    }
}
