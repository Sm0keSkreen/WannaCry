package dev.mg.wannacry.features.commands;

import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import dev.mg.wannacry.Satellite;
import dev.mg.wannacry.features.commands.argument.ColorArgumentType;
import dev.mg.wannacry.features.modules.Module;
import dev.mg.wannacry.features.settings.Setting;
import dev.mg.wannacry.manager.CommandManager;
import dev.mg.wannacry.util.chat.ChatUtil;
import java.awt.*;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2583;

import static com.mojang.brigadier.arguments.BoolArgumentType.getBool;
import static com.mojang.brigadier.arguments.StringArgumentType.getString;
import static com.mojang.brigadier.arguments.StringArgumentType.greedyString;
import static dev.mg.wannacry.features.commands.argument.ColorArgumentType.getColor;
import static dev.mg.wannacry.features.commands.argument.EnumArgumentType._enum;
import static dev.mg.wannacry.features.commands.argument.EnumArgumentType.getEnum;
import static dev.mg.wannacry.features.commands.argument.NumberArgumentType.*;

public class ModuleCommand extends Command {
    private final Module module;

    public ModuleCommand(Module module) {
        super(module.getName().toLowerCase());
        setDescription("Command line configuration implementation for \"" + module.getName() + "\"");
        this.module = module;
    }

    @SuppressWarnings("unchecked")
    @Override
    public void createArgumentBuilder(LiteralArgumentBuilder<CommandManager> builder) {
        registerDefault(builder);
        for (Setting<?> setting : module.getSettings()) {
            Class<?> type = setting.getDefaultValue().getClass();

            if (Boolean.class.isAssignableFrom(type)) {
                registerBooleanArgument(builder, (Setting<Boolean>) setting);
            } else if (Number.class.isAssignableFrom(type)) {
                registerNumberArgument(builder, (Setting<? extends Number>) setting);
            } else if (Enum.class.isAssignableFrom(type)) {
                registerEnumArgument(builder, (Setting<Enum<?>>) setting);
            } else if (String.class.isAssignableFrom(type)) {
                registerStringArgument(builder, (Setting<String>) setting);
            } else if (Color.class.isAssignableFrom(type)) {
                registerColorArgument(builder, (Setting<Color>) setting);
            }
        }
    }

    private void registerDefault(LiteralArgumentBuilder<CommandManager> builder) {
        builder.executes(ctx -> {
            var message = class_2561.method_43473();

            message.method_27693("[ ");
            message.method_10852(class_2561.method_43470(module.getName())
                    .method_27694(s -> s.method_10977(module.isToggled() ? class_124.field_1060 : class_124.field_1061))
                    .method_27694(s -> s.method_10958(suggestCommand("toggle " + module.getName())))
            );
            message.method_27693(" ]");

            for (Setting<?> setting : module.getSettings()) {
                message.method_27693("\n");
                message.method_10852(class_2561.method_43470(setting.getName() + ": ").method_27692(class_124.field_1080));
                message.method_10852(class_2561.method_43470(setting.getValueAsString()).method_27694(s -> styledValue(setting, s)));
            }

            ChatUtil.sendMessage(message, MessageSignatures.SUCCESS);

            return success();
        });
    }

    private void registerColorArgument(LiteralArgumentBuilder<CommandManager> builder,
                                       Setting<Color> setting) {
        builder.then(literal(setting.getName().toLowerCase())
                .then(argument("value", ColorArgumentType.color())
                        .executes((ctx) -> {
                            setting.setValue(getColor(ctx, "value"));
                            Color value = setting.getValue();
                            return success("Set %s.%s to RGB(%s, %s, %s)",
                                    module.getName(),
                                    setting.getName(),
                                    value.getRed(),
                                    value.getGreen(),
                                    value.getBlue());
                        })));
    }

    private void registerStringArgument(LiteralArgumentBuilder<CommandManager> builder,
                                        Setting<String> setting) {
        builder.then(literal(setting.getName().toLowerCase())
                .then(argument("value", greedyString())
                        .executes((ctx) -> {
                            setting.setValue(getString(ctx, "value"));
                            return settingChangeReturn(setting);
                        })));
    }

    @SuppressWarnings("unchecked")
    private void registerEnumArgument(LiteralArgumentBuilder<CommandManager> builder,
                                      Setting<Enum<?>> setting) {
        Class<Enum<?>> type = (Class<Enum<?>>) setting.getDefaultValue().getClass();
        builder.then(literal(setting.getName().toLowerCase())
                .then(argument("value", _enum(type))
                        .executes((ctx) -> {
                            setting.setValue(getEnum(ctx, "value"));
                            return settingChangeReturn(setting);
                        })));
    }

    @SuppressWarnings("unchecked")
    private <T extends Number> void registerNumberArgument(LiteralArgumentBuilder<CommandManager> builder,
                                                           Setting<T> setting) {
        Class<T> type = (Class<T>) setting.getDefaultValue().getClass();
        builder.then(literal(setting.getName().toLowerCase())
                .then(argument("value", number(type, minMax(setting.getMin(), setting.getMax())))
                        .executes((ctx) -> {
                            setting.setValue(get(type, ctx, "value"));
                            return settingChangeReturn(setting);
                        })));
    }

    private void registerBooleanArgument(LiteralArgumentBuilder<CommandManager> builder,
                                         Setting<Boolean> setting) {
        builder.then(literal(setting.getName().toLowerCase())
                .then(argument("value", BoolArgumentType.bool())
                        .executes((ctx) -> {
                            setting.setValue(getBool(ctx, "value"));
                            return settingChangeReturn(setting);
                        })));
    }

    private int settingChangeReturn(final Setting<?> setting) {
        return success("Set %s.%s to %s", module.getName(), setting.getName(), setting.getValue());
    }

    private static class_2558 suggestCommand(String command) {
        return new class_2558.class_10610(Satellite.commandManager.getCommandPrefix() + command);
    }

    private static class_2583 styledValue(Setting<?> setting, class_2583 style) {
        return switch (setting.getValue()) {
            case Boolean value -> style.method_10977(value ? class_124.field_1060 : class_124.field_1061);
            case Color value -> style.method_36139(value.getRGB());
            case Enum<?> ignored -> style.method_10977(class_124.field_1054);
            default -> style.method_10977(class_124.field_1068);
        };
    }

    @Override
    public boolean isShown() {
        return false;
    }
}
