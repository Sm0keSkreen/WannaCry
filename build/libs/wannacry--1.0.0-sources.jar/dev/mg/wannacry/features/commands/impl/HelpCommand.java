package dev.mg.wannacry.features.commands.impl;

import com.google.common.collect.Iterables;
import com.mojang.brigadier.ParseResults;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.tree.CommandNode;
import dev.mg.wannacry.Satellite;
import dev.mg.wannacry.features.commands.Command;
import dev.mg.wannacry.manager.CommandManager;
import dev.mg.wannacry.util.chat.ChatUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2564;
import net.minecraft.class_5250;

import static dev.mg.wannacry.features.commands.MessageSignatures.GENERAL;
import static dev.mg.wannacry.features.commands.argument.CommandArgumentType.command;
import static dev.mg.wannacry.features.commands.argument.CommandArgumentType.getCommand;
import static dev.mg.wannacry.features.commands.argument.NumberArgumentType.get;
import static dev.mg.wannacry.features.commands.argument.NumberArgumentType.number;
import static dev.mg.wannacry.util.TextUtil.text;
import static dev.mg.wannacry.util.chat.ChatUtil.prefix;
import static dev.mg.wannacry.util.chat.ChatUtil.withPrefix;

public class HelpCommand extends Command {
    private static final int ITEMS_PER_PAGE = 5;

    public HelpCommand() {
        super("help", "commands", "h", "cmds");
        setDescription("Displays all executable commands and additional information");
    }

    @Override
    public void createArgumentBuilder(LiteralArgumentBuilder<CommandManager> builder) {
        builder.then(argument("page", number(Integer.class))
                        .executes((ctx) -> helpCommands(ctx, get(Integer.class, ctx, "page"))))
                .then(argument("command_name", command())
                        .executes(this::helpSpecific))
                .executes((ctx) -> helpCommands(ctx, 1));
    }

    private int helpSpecific(CommandContext<CommandManager> ctx) {
        Command command = getCommand(ctx, "command_name");

        class_5250 text = class_2561.method_43473();
        text.method_10852(withPrefix("Usages for %s:\n", command.getName()));

        ParseResults<CommandManager> results = ctx.getSource().getDispatcher()
                .parse(command.getName(), ctx.getSource());

        if (results.getContext().getNodes().isEmpty()) {
            text.method_10852(withPrefix("No usages available"));
        } else {
            Map<CommandNode<CommandManager>, String> smartUsages = ctx.getSource().getDispatcher().getSmartUsage(
                    Iterables.getLast(results.getContext().getNodes()).getNode(), ctx.getSource());
            List<class_2561> usages = new ArrayList<>();

            for (String usage : smartUsages.values()) {
                usages.add(text("   {gray}.%s %s", command.getName(), usage));
            }

            text.method_10852(class_2564.method_37112(usages, class_2561.method_43470("\n")));
        }

        ChatUtil.sendClientSideMessage(text, GENERAL);
        return success();
    }

    private int helpCommands(CommandContext<CommandManager> ctx, int page) {
        List<Command> commands = ctx.getSource().getCommands()
                .stream().filter(Command::isShown).toList();

        int pageIndex = page;
        int pages = (int) Math.ceil((double) commands.size() / ITEMS_PER_PAGE);
        if (pageIndex > pages) {
            pageIndex = 1;
        }

        List<Command> paginated = commands.subList((pageIndex - 1) * ITEMS_PER_PAGE,
                Math.min(commands.size(), pageIndex * ITEMS_PER_PAGE));

        class_5250 text = class_2561.method_43473();
        text.method_10852(withPrefix("Commands (%s): \n", commands.size()));

        for (Command command : paginated) {
            String aliases = String.join(", ", command.getAliases());
            String description = command.getDescription();
            text.method_10852(withPrefix("{dark_gray} %s: {reset}\n   %s\n", aliases, description));
        }

        text.method_10852(buildPages(pageIndex, pages));

        ChatUtil.sendClientSideMessage(text, GENERAL);
        return success();
    }

    private static class_2561 buildPages(int index, int pages) {
        String command = Satellite.commandManager.getCommandPrefix() + "help ";
        class_5250 text = prefix();
        boolean hasPages = pages > 1;

        if (hasPages && index != 1)
            text.method_10852(suggest(class_2561.method_43470(" <"), command + (index - 1)));

        text.method_10852(text(" Page %d/%d", index, pages));

        if (hasPages && index != pages)
            text.method_10852(suggest(class_2561.method_43470(" > "), command + (index + 1)));

        return text;
    }

    private static class_2561 suggest(class_5250 component, String command) {
        return component.method_27694(s -> s.method_10958(new class_2558.class_10610(command.formatted())));
    }
}
