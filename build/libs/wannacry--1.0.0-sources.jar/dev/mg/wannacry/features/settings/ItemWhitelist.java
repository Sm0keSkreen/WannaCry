package dev.mg.wannacry.features.settings;

import java.util.*;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ItemWhitelist {

    public static final String FIST_ID = "satellite:fist";

    private final LinkedHashSet<String> ids = new LinkedHashSet<>();

    public ItemWhitelist() {}

    public ItemWhitelist(String... initialIds) {
        ids.addAll(Arrays.asList(initialIds));
    }

    public boolean isAllowed(class_1799 held) {
        if (held == null || held.method_7960()) {
            return ids.contains(FIST_ID);
        }
        String id = itemToId(held.method_7909());
        return ids.contains(id);
    }

    public boolean contains(String id)  { return ids.contains(id); }
    public boolean isEmpty()            { return ids.isEmpty(); }
    public int     size()               { return ids.size(); }

    public boolean add(String id)       { return ids.add(id); }

    public boolean remove(String id)    { return ids.remove(id); }

    public void toggle(String id) {
        if (!ids.remove(id)) ids.add(id);
    }

    public Set<String> getIds() { return Collections.unmodifiableSet(ids); }

    public String serialize() {
        return String.join(",", ids);
    }

    public void deserialize(String data) {
        ids.clear();
        if (data == null || data.isBlank()) return;
        for (String part : data.split(",")) {
            String trimmed = part.trim();
            if (!trimmed.isEmpty()) ids.add(trimmed);
        }
    }

    public static String itemToId(class_1792 item) {
        class_2960 key = class_7923.field_41178.method_10221(item);
        return key != null ? key.toString() : "minecraft:air";
    }

    public static class_1792 idToItem(String id) {
        try {
            return class_7923.field_41178.method_63535(class_2960.method_60654(id));
        } catch (Exception e) {
            return class_1802.field_8162;
        }
    }

    public static String displayName(String id) {
        if (FIST_ID.equals(id)) return "Fist (Empty Hand)";
        class_1792 item = idToItem(id);
        if (item == class_1802.field_8162) return id;
        return item.method_7864(item.method_7854()).getString();
    }

    public static List<String> searchItems(String query) {
        String lower = query == null ? "" : query.toLowerCase(Locale.ROOT);
        List<String> result = new ArrayList<>();

        if (lower.isEmpty() || "fist".contains(lower) || "empty hand".contains(lower)
                || FIST_ID.contains(lower)) {
            result.add(FIST_ID);
        }

        class_7923.field_41178.method_10220()
                .filter(item -> item != class_1802.field_8162)
                .sorted(Comparator.comparing(ItemWhitelist::itemToId))
                .forEach(item -> {
                    String id   = itemToId(item);
                    String name = item.method_7864(item.method_7854()).getString().toLowerCase(Locale.ROOT);
                    if (lower.isEmpty() || id.contains(lower) || name.contains(lower)) {
                        result.add(id);
                    }
                });

        return result;
    }
}
