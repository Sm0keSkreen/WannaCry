package dev.mg.wannacry.features.gui.items.buttons;

import dev.mg.wannacry.Satellite;
import dev.mg.wannacry.features.gui.SatelliteGui;
import dev.mg.wannacry.features.modules.client.ClickGuiModule;
import dev.mg.wannacry.features.settings.Bind;
import dev.mg.wannacry.features.settings.Setting;
import dev.mg.wannacry.util.KeyboardUtil;
import dev.mg.wannacry.util.render.RenderUtil;
import net.minecraft.class_1109;
import net.minecraft.class_124;
import net.minecraft.class_332;
import dev.mg.wannacry.util.SatelliteSounds;
import org.lwjgl.glfw.GLFW;

public class BindButton extends Button {
    private final Setting<Bind> setting;
    public boolean isListening;

    public BindButton(Setting<Bind> setting) {
        super(setting.getName());
        this.setting = setting;
        this.width = 15;
    }

    @Override
    public void drawScreen(class_332 context, int mouseX, int mouseY, float partialTicks) {
        ClickGuiModule gui = ClickGuiModule.getInstance();
        boolean hovering = isHovering(mouseX, mouseY);

        int sh = getSettingItemHeight();
        int bg = getState()
                ? (hovering ? brighten(0x11555555, gui != null ? gui.hoverBrightness.getValue() : 40) : 0x11555555)
                : (hovering ? Satellite.colorManager.getColorWithAlpha(y, gui != null ? gui.topColor.getValue().getAlpha() : 200)
                            : Satellite.colorManager.getColorWithAlpha(y, gui != null ? gui.color.getValue().getAlpha() : 180));
        RenderUtil.rect(context, this.x, this.y, this.x + (float)this.width + 7.4f,
                this.y + sh + 0.5f, bg);

        float scale = gui != null ? gui.settingTextSize.getValue() : 1.0f;
        String text = isListening ? "Press a Key..."
                : setting.getName() + " " + class_124.field_1080 + KeyboardUtil.getKeyName(setting.getValue());
        drawScaledText(context, text, this.x + 2.3f, settingTextY(), getState() ? -1 : -5592406, scale);
    }

    @Override public int getHeight() { return getSettingItemHeight(); }
    @Override public void update() { setHidden(!setting.isVisible()); }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        if (isListening) {
            if (mouseButton != 0 && mouseButton != 1) {
                setting.setValue(new Bind(-mouseButton - 2));
                onMouseClick();
            }
        } else if (isHovering(mouseX, mouseY)) {
            mc.method_1483().method_4873(class_1109.method_4758(SatelliteSounds.UI_CLICK, 1f));
        }
    }

    @Override
    public void onKeyPressed(int key) {
        if (isListening) {
            Bind bind = new Bind(key);
            if (key == GLFW.GLFW_KEY_DELETE || key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_ESCAPE)
                bind = new Bind(-1);
            setting.setValue(bind);
            onMouseClick();
        }
    }

    @Override public void toggle() { isListening = !isListening; }
    @Override public boolean getState() { return !isListening; }
}
