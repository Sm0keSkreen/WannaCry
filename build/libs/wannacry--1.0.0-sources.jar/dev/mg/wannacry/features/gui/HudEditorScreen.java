package dev.mg.wannacry.features.gui;

import dev.mg.wannacry.Satellite;
import dev.mg.wannacry.features.Feature;
import dev.mg.wannacry.features.gui.items.buttons.ModuleButton;
import dev.mg.wannacry.features.modules.Module;
import dev.mg.wannacry.features.modules.client.HudModule;
import java.util.ArrayList;
import java.util.Comparator;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class HudEditorScreen extends class_437 {
    private static HudEditorScreen INSTANCE;

    private final ArrayList<Widget> components = new ArrayList<>();
    public HudModule currentDragging;
    public boolean anyHover;

    private HudEditorScreen() {
        super(class_2561.method_43470("satellite-hudeditor"));
        load();
    }

    private void load() {
        Widget hud = new Widget("Hud", 50, 50, true);
        Satellite.moduleManager.stream()
                .filter(m -> m.getCategory() == Module.Category.HUD && !m.hidden)
                .map(ModuleButton::new)
                .forEach(hud::addButton);
        this.components.add(hud);
        this.components.forEach(component -> component.getItems().sort(Comparator.comparing(Feature::getName)));
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        anyHover = false;
        this.components.forEach(component -> component.drawScreen(context, mouseX, mouseY, delta));
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubled) {
        this.components.forEach(component -> component.mouseClicked((int) click.comp_4798(), (int) click.comp_4799(), click.method_74245()));
        return super.method_25402(click, doubled);
    }

    @Override
    public boolean method_25406(class_11909 click) {
        this.components.forEach(component -> component.mouseReleased((int) click.comp_4798(), (int) click.comp_4799(), click.method_74245()));
        return super.method_25406(click);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (verticalAmount < 0) {
            this.components.forEach(component -> component.setY(component.getY() - 10));
        } else if (verticalAmount > 0) {
            this.components.forEach(component -> component.setY(component.getY() + 10));
        }
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean method_25404(class_11908 input) {
        this.components.forEach(component -> component.onKeyPressed(input.method_74228()));
        return super.method_25404(input);
    }

    @Override
    public boolean method_25400(class_11905 input) {
        this.components.forEach(component -> component.onKeyTyped(input.method_74226(), input.comp_4794()));
        return super.method_25400(input);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
    }

    public ArrayList<Widget> getComponents() {
        return components;
    }

    public static HudEditorScreen getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new HudEditorScreen();
        }
        return INSTANCE;
    }
}

