package dev.mg.wannacry.features.modules.player;

import dev.mg.wannacry.event.impl.entity.player.TickEvent;
import dev.mg.wannacry.event.system.Subscribe;
import dev.mg.wannacry.features.modules.Module;
import dev.mg.wannacry.features.settings.Setting;
import java.util.Random;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_2846;
import net.minecraft.class_3965;

public class FastBreakModule extends Module {

    private final Setting<Float> activationChance = num(
            "ActivationChance", 1.0f, 0.0f, 1.0f);

    private final Setting<Boolean> legitMode = bool(
            "LegitMode", false);

    private final Random random = new Random();

    private class_2338 lastBlockPos = null;

    private boolean fastBreakBlock = false;

    public FastBreakModule() {
        super("FastBreak", "Mine blocks faster and removes the delay between breaks.", Category.CLOSET);
        legitMode.setVisibility(v -> true);
        activationChance.setVisibility(v -> !legitMode.getValue());
    }

    @Subscribe
    public void onPreTick(TickEvent.Pre event) {
        if (nullCheck()) return;

        mc.field_1761.field_3716 = 0;

        if (legitMode.getValue()) return;

        if (!(mc.field_1765 instanceof class_3965 hit)
                || hit.method_17783() != class_239.class_240.field_1332) {
            lastBlockPos = null;
            return;
        }

        class_2338 blockPos = hit.method_17777();

        if (!blockPos.equals(lastBlockPos)) {
            lastBlockPos = blockPos;
            fastBreakBlock = random.nextFloat() <= activationChance.getValue();
        }

        if (!fastBreakBlock) return;

        class_2680 state = mc.field_1687.method_8320(blockPos);
        if (state.method_26214(mc.field_1687, blockPos) < 0) return;

        if (mc.field_1761.field_3715 <= 0) return;

        if (mc.field_1761.field_3715 >= 1) return;

        class_2350 direction = hit.method_17780();
        mc.field_1724.field_3944.method_52787(
                new class_2846(
                        class_2846.class_2847.field_12973,
                        blockPos,
                        direction,
                        (int) mc.field_1724.method_73183().method_75260()));
    }

    @Override
    public void onDisable() {
        lastBlockPos = null;
    }

    @Override
    public String getDisplayInfo() {
        return legitMode.getValue() ? "Legit" : null;
    }
}
