package dev.mg.wannacry.features.modules.combat;

import dev.mg.wannacry.Satellite;
import dev.mg.wannacry.event.Stage;
import dev.mg.wannacry.event.impl.ClientEvent;
import dev.mg.wannacry.event.impl.entity.player.TravelEvent;
import dev.mg.wannacry.event.impl.entity.player.UpdateWalkingPlayerEvent;
import dev.mg.wannacry.event.impl.network.PacketEvent;
import dev.mg.wannacry.event.impl.render.Render2DEvent;
import dev.mg.wannacry.event.system.Subscribe;
import dev.mg.wannacry.features.modules.Module;
import dev.mg.wannacry.features.settings.Setting;
import dev.mg.wannacry.util.models.Angles;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2824;
import net.minecraft.class_3532;

public class AimCorrectionModule extends Module {

    public enum TargetType { PLAYERS, MOBS, ENTITIES }
    public enum AimMode    { NEAREST, LOWEST_HP }

    private final Setting<TargetType> targets    = mode("Targets",  TargetType.PLAYERS);
    private final Setting<AimMode>    aimMode    = mode("AimAt",    AimMode.NEAREST);
    private final Setting<Boolean>    aimLastHit = bool("AimAtLastHit", false);

    private final Setting<Float> hSpeedMin = num("HorizontalSpeedMin", 120f, 1f, 720f);
    private final Setting<Float> hSpeedMax = num("HorizontalSpeedMax", 120f, 1f, 720f);
    private final Setting<Float> vSpeedMin = num("VerticalSpeedMin",    80f, 1f, 720f);
    private final Setting<Float> vSpeedMax = num("VerticalSpeedMax",    80f, 1f, 720f);

    private final Setting<Boolean> stopH          = bool("StopOnHitboxHorizontal", true);
    private final Setting<Boolean> stopV          = bool("StopOnHitboxVertical",   true);
    private final Setting<Boolean> stopAtPitchLock = bool("StopAtPitchLock",       false);

    private final Setting<Float> rangeMin = num("RangeMin", 6f, 1f, 12f);
    private final Setting<Float> rangeMax = num("RangeMax", 6f, 1f, 12f);

    private float currentHSpeed = 120f;
    private float currentVSpeed =  80f;
    private float currentRange  =   6f;
    private class_1309 prevTarget = null;

    private class_1309 lastHitTarget    = null;
    private long         lastFrameNs      = -1L;

    private float prevPlayerYaw   = 0f;
    private float prevPlayerPitch = 0f;

    private boolean returningToCamera = false;

    private volatile boolean windingDown = false;

    private volatile float   camYaw      = 0f;
    private volatile float   camPitch    = 0f;
    private volatile boolean cameraActive = false;

    private Angles syncAngles = null;

    private Angles travelSnapshot = null;

    private Angles walkingSnapshot = null;

    private Angles rotLastSnapshot = null;

    private volatile boolean swapInProgress = false;

    private boolean playerIsMoving = false;

    private float lastSentSwapYaw = Float.NaN;

    public AimCorrectionModule() {
        super("AimCorrection",
              "Silent aim",
              Category.CLOSET);
    }

    public float   getCamYaw()      { return camYaw;      }
    public float   getCamPitch()    { return camPitch;    }
    public boolean isCameraActive() { return cameraActive; }
    public Angles  getSyncAngles()  { return syncAngles;  }

    public boolean isWindingDown()  { return windingDown;  }

    @Override
    public void onEnable() {
        if (nullCheck()) return;
        camYaw            = mc.field_1724.method_36454();
        camPitch          = mc.field_1724.method_36455();
        prevPlayerYaw     = mc.field_1724.method_36454();
        prevPlayerPitch   = mc.field_1724.method_36455();
        cameraActive      = true;
        lastFrameNs       = -1L;
        returningToCamera = false;
        windingDown       = false;
        lastSentSwapYaw   = Float.NaN;
        rollValues();
    }

    @Override
    public void disable() {
        if (!nullCheck() && cameraActive && !windingDown) {
            windingDown = true;

            this.enabled.setValue(false);
            EVENT_BUS.post(new ClientEvent(ClientEvent.Type.TOGGLE_MODULE, this));
            this.onToggle();

        } else {
            windingDown = false;
            super.disable();
        }
    }

    @Override
    public void onDisable() {
        lastHitTarget     = null;
        prevTarget        = null;
        lastFrameNs       = -1L;
        cameraActive      = false;
        returningToCamera = false;
        windingDown       = false;
        syncAngles        = null;
        travelSnapshot    = null;
        walkingSnapshot   = null;
        rotLastSnapshot   = null;
        swapInProgress    = false;
        playerIsMoving    = false;
        lastSentSwapYaw   = Float.NaN;
    }

    @Subscribe
    public void onPacketSend(PacketEvent.Send event) {
        if (!(event.getPacket() instanceof class_2824 pkt)) return;
        if (pkt.field_12871.method_34211() != class_2824.class_5907.field_29172) return;
        class_1297 entity = mc.field_1687.method_8469(pkt.field_12870);
        if (entity instanceof class_1309 living && living != mc.field_1724) {
            lastHitTarget = living;
        }
    }

    @Subscribe
    public void onTravelPre(TravelEvent.Pre event) {
        if (syncAngles == null || nullCheck()) return;

        net.minecraft.class_243 vel = mc.field_1724.method_18798();
        playerIsMoving = (vel.field_1352 * vel.field_1352 + vel.field_1350 * vel.field_1350) > 1e-6;
        if (!playerIsMoving) return;

        travelSnapshot = new Angles(mc.field_1724.method_36454(), mc.field_1724.method_36455());
        swapInProgress = true;
        mc.field_1724.method_36456(syncAngles.yRot());
        mc.field_1724.method_36457(syncAngles.xRot());
    }

    @Subscribe
    public void onTravelPost(TravelEvent.Post event) {

        if (travelSnapshot != null && syncAngles == null) {
            mc.field_1724.method_36456(travelSnapshot.yRot());
            mc.field_1724.method_36457(travelSnapshot.xRot());
            travelSnapshot = null;
            swapInProgress = false;
        }

    }

    @Subscribe
    public void onUpdateWalking(UpdateWalkingPlayerEvent event) {
        if (syncAngles == null || nullCheck()) return;

        if (event.getStage() == Stage.PRE && !playerIsMoving) {

            if (!Float.isNaN(lastSentSwapYaw)) {
                float yawDelta = Math.abs(class_3532.method_15393(mc.field_1724.method_36454() - lastSentSwapYaw));
                if (yawDelta < 0.002f) {
                    mc.field_1724.method_36456(lastSentSwapYaw + 0.001f);
                }
                lastSentSwapYaw = Float.NaN;
            }

            if (mc.field_1724.field_3923 >= 19) {
                float yawDelta = Math.abs(mc.field_1724.method_36454() - mc.field_1724.field_3941);
                if (yawDelta < 0.001f) {
                    mc.field_1724.method_36456(mc.field_1724.method_36454() + 0.001f);
                }
            }
        }

        if (!playerIsMoving) return;

        if (event.getStage() == Stage.PRE) {

            if (travelSnapshot != null) {
                walkingSnapshot = travelSnapshot;
                travelSnapshot  = null;
            } else {
                walkingSnapshot = new Angles(mc.field_1724.method_36454(), mc.field_1724.method_36455());
            }
            rotLastSnapshot = new Angles(mc.field_1724.field_3941,  mc.field_1724.field_3925);

            float sendYaw = syncAngles.yRot();
            if (!Float.isNaN(lastSentSwapYaw)
                    && Math.abs(class_3532.method_15393(sendYaw - lastSentSwapYaw)) < 0.001f) {
                sendYaw = lastSentSwapYaw + 0.001f;
            }
            lastSentSwapYaw = sendYaw;

            mc.field_1724.method_36456(sendYaw);
            mc.field_1724.method_36457(syncAngles.xRot());
        } else if (walkingSnapshot != null) {

            mc.field_1724.method_36456(walkingSnapshot.yRot());
            mc.field_1724.method_36457(walkingSnapshot.xRot());

            if (rotLastSnapshot != null) {
                mc.field_1724.field_3941 = rotLastSnapshot.yRot();
                mc.field_1724.field_3925 = rotLastSnapshot.xRot();
                rotLastSnapshot = null;
            }
            walkingSnapshot = null;

            swapInProgress = false;
        }
    }

    @Subscribe
    public void onRender2D(Render2DEvent event) {
        if (nullCheck()) return;

        long nowNs = System.nanoTime();
        if (lastFrameNs < 0L) {
            lastFrameNs     = nowNs;
            prevPlayerYaw   = mc.field_1724.method_36454();
            prevPlayerPitch = mc.field_1724.method_36455();
            camYaw          = mc.field_1724.method_36454();
            camPitch        = mc.field_1724.method_36455();
            cameraActive    = true;
            return;
        }
        float deltaMs = Math.min((nowNs - lastFrameNs) / 1_000_000f, 100f);
        lastFrameNs = nowNs;

        if (swapInProgress) return;

        float maxYaw   = currentHSpeed * (deltaMs / 1000f);
        float maxPitch = currentVSpeed * (deltaMs / 1000f);

        float mouseDeltaYaw   = class_3532.method_15393(mc.field_1724.method_36454() - prevPlayerYaw);
        float mouseDeltaPitch =                  mc.field_1724.method_36455() - prevPlayerPitch;

        camYaw   = class_3532.method_15393(camYaw   + mouseDeltaYaw);
        camPitch = class_3532.method_15363(camPitch + mouseDeltaPitch, -90f, 90f);
        cameraActive = true;

        boolean pitchLocked = stopAtPitchLock.getValue()
                && Math.abs(camPitch) >= 89.9f;

        class_1309 target = windingDown ? null : findTarget();

        if (target != prevTarget) {
            if (target != null) rollValues();
            prevTarget = target;
        }

        if (target != null && !pitchLocked) {

            returningToCamera = false;

            class_243 eyePos = mc.field_1724.method_33571();
            class_238 box    = target.method_5829();
            class_243 center = box.method_1005();

            class_243    nearest    = clampToAABB(eyePos, box);
            float[] nearAngles = calcAngle(eyePos, nearest);

            float yawDiff   = class_3532.method_15393(nearAngles[0] - mc.field_1724.method_36454());
            float pitchDiff = nearAngles[1] - mc.field_1724.method_36455();

            if (stopH.getValue() || stopV.getValue()) {
                float[] ca  = calcAngle(eyePos, center);
                double  dxz = Math.max(Math.sqrt(
                        (center.field_1352 - eyePos.field_1352) * (center.field_1352 - eyePos.field_1352) +
                        (center.field_1350 - eyePos.field_1350) * (center.field_1350 - eyePos.field_1350)), 0.01);
                double  d3  = Math.max(eyePos.method_1022(center), 0.01);
                float halfW = (float) Math.toDegrees(Math.atan2(target.method_17681()  * 0.5, dxz));
                float halfH = (float) Math.toDegrees(Math.atan2(target.method_17682() * 0.5, d3));

                if (stopH.getValue() && Math.abs(class_3532.method_15393(ca[0] - mc.field_1724.method_36454())) <= halfW) yawDiff   = 0f;
                if (stopV.getValue() && Math.abs(ca[1] - mc.field_1724.method_36455())                  <= halfH) pitchDiff = 0f;
            }

            if (yawDiff != 0f || pitchDiff != 0f) {
                mc.field_1724.method_36456(mc.field_1724.method_36454() + clampAbs(yawDiff,   maxYaw));
                mc.field_1724.method_36457(class_3532.method_15363(mc.field_1724.method_36455() + clampAbs(pitchDiff, maxPitch), -90f, 90f));
            }

            syncAngles = new Angles(mc.field_1724.method_36454(), mc.field_1724.method_36455());

        } else {

            returningToCamera = true;
            syncAngles = null;

            lastSentSwapYaw = Float.NaN;

            float yawDiff   = class_3532.method_15393(camYaw   - mc.field_1724.method_36454());
            float pitchDiff =                  camPitch - mc.field_1724.method_36455();

            boolean arrivedYaw   = Math.abs(yawDiff)   <= maxYaw;
            boolean arrivedPitch = Math.abs(pitchDiff) <= maxPitch;

            if (arrivedYaw && arrivedPitch) {

                mc.field_1724.method_36456(camYaw);
                mc.field_1724.method_36457(camPitch);
                returningToCamera = false;

                if (windingDown) {

                    cameraActive = false;
                    windingDown  = false;
                    EVENT_BUS.unregister(this);
                    this.onDisable();
                } else {

                    cameraActive = false;
                }
            } else {
                mc.field_1724.method_36456(mc.field_1724.method_36454() + clampAbs(yawDiff,   maxYaw));
                mc.field_1724.method_36457(class_3532.method_15363(mc.field_1724.method_36455() + clampAbs(pitchDiff, maxPitch), -90f, 90f));
            }
        }

        prevPlayerYaw   = mc.field_1724.method_36454();
        prevPlayerPitch = mc.field_1724.method_36455();
    }

    private class_1309 findTarget() {
        if (aimLastHit.getValue() && lastHitTarget != null) {
            if (lastHitTarget instanceof class_1657 p && Satellite.friendManager.isFriend(p)) {
                lastHitTarget = null;
            } else if (isValidTarget(lastHitTarget)) {
                return lastHitTarget;
            } else {
                lastHitTarget = null;
            }
        }

        class_1309 best    = null;
        float        bestVal = Float.MAX_VALUE;

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (!(entity instanceof class_1309 living)) continue;
            if (!isValidTarget(living)) continue;

            float val = switch (aimMode.getValue()) {
                case NEAREST   -> living.method_5739(mc.field_1724);
                case LOWEST_HP -> living.method_6032();
            };

            if (val < bestVal) {
                bestVal = val;
                best    = living;
            }
        }
        return best;
    }

    private boolean isValidTarget(class_1309 living) {
        if (living == mc.field_1724) return false;
        if (living.method_31481() || !living.method_5805()) return false;
        if (living.method_5739(mc.field_1724) > currentRange) return false;
        if (living instanceof class_1657 p && Satellite.friendManager.isFriend(p)) return false;

        return switch (targets.getValue()) {
            case PLAYERS  -> living instanceof class_1657;
            case MOBS     -> living instanceof class_1308;
            case ENTITIES -> true;
        };
    }

    private static float[] calcAngle(class_243 from, class_243 to) {
        double dx    =  (to.field_1352 - from.field_1352);
        double dy    = -(to.field_1351 - from.field_1351);
        double dz    =  (to.field_1350 - from.field_1350);
        double dist  = Math.sqrt(dx * dx + dz * dz);
        float  yaw   = (float) class_3532.method_15338(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float  pitch = (float) class_3532.method_15338(Math.toDegrees(Math.atan2(dy, dist)));
        return new float[]{ yaw, pitch };
    }

    private static class_243 clampToAABB(class_243 point, class_238 box) {
        return new class_243(
                class_3532.method_15350(point.field_1352, box.field_1323, box.field_1320),
                class_3532.method_15350(point.field_1351, box.field_1322, box.field_1325),
                class_3532.method_15350(point.field_1350, box.field_1321, box.field_1324));
    }

    private static float clampAbs(float value, float maxAbs) {
        if (value > 0f) return Math.min( value,  maxAbs);
        if (value < 0f) return Math.max( value, -maxAbs);
        return 0f;
    }

    private static float rollFloat(float a, float b) {
        float lo = Math.min(a, b), hi = Math.max(a, b);
        return (lo == hi) ? lo : lo + (float) (Math.random() * (hi - lo));
    }

    private void rollValues() {
        currentHSpeed = rollFloat(hSpeedMin.getValue(), hSpeedMax.getValue());
        currentVSpeed = rollFloat(vSpeedMin.getValue(), vSpeedMax.getValue());
        currentRange  = rollFloat(rangeMin.getValue(),  rangeMax.getValue());
    }

    @Override
    public String getDisplayInfo() {
        return targets.getValue().name().charAt(0)
             + targets.getValue().name().substring(1).toLowerCase();
    }
}
