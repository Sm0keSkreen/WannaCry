package dev.mg.wannacry.features.modules.movement;

import dev.mg.wannacry.event.impl.entity.player.TickEvent;
import dev.mg.wannacry.event.system.Subscribe;
import dev.mg.wannacry.features.modules.Module;
import net.minecraft.class_241;

public class AutoSprintModule extends Module {
    public AutoSprintModule() {
        super("Sprint", "Automatically sprints for you.", Category.CLOSET);
    }

    @Subscribe
    public void onPreTick(TickEvent.Pre event) {
        if (nullCheck()) return;

        class_241 move = mc.field_1724.field_3913.method_3128();
        if (move.field_1342 != 0 && !mc.field_1724.method_5624() && !mc.field_1724.method_5799()
                && !mc.field_1724.method_5869() && !mc.field_1724.method_18276()
                && mc.field_1724.method_7344().method_7586() > 6) {
            mc.field_1724.method_5728(true);
        }
    }

    @Override
    public void onDisable() {
        if (nullCheck()) return;
        mc.field_1724.method_5728(false);
    }
}
