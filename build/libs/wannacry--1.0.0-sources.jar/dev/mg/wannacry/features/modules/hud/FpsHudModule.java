package dev.mg.wannacry.features.modules.hud;

import dev.mg.wannacry.Satellite;
import dev.mg.wannacry.event.impl.render.Render2DEvent;
import dev.mg.wannacry.features.modules.client.HudModule;
import dev.mg.wannacry.features.settings.Setting;
import java.awt.*;
import net.minecraft.class_327;

public class FpsHudModule extends HudModule {
    public final Setting<Color> color = color("Color", 255, 255, 255, 255);

    public FpsHudModule() {
        super("FPS", "Display current FPS", 60, 10);
    }

    @Override
    protected void render(Render2DEvent e) {
        super.render(e);

        String text = "FPS: " + mc.method_47599();

        class_327 font = Satellite.fontService.getFont();
        int textW = font.method_1727(text);
        int textH = Satellite.fontService.getHeight();

        drawTextGlow(e.getContext(), text, (int) getX(), (int) getY());

        if (gradientEnabled.getValue()) {
            drawGradientText(e.getContext(), text, (int) getX(), (int) getY());
        } else {
            Satellite.fontService.drawText(e.getContext(), text,
                    (int) getX(), (int) getY(), color.getValue().getRGB(), false);
        }

        setWidth(textW);
        setHeight(textH);
    }
}
