package dev.mg.wannacry.features.modules.combat;

import dev.mg.wannacry.event.impl.input.AttackEvent;
import dev.mg.wannacry.event.system.Subscribe;
import dev.mg.wannacry.features.modules.Module;
import dev.mg.wannacry.features.settings.Setting;
import dev.mg.wannacry.util.EnchantmentUtil;
import dev.mg.wannacry.util.inventory.InventoryUtil;
import dev.mg.wannacry.util.inventory.Result;
import dev.mg.wannacry.util.inventory.ResultType;
import java.util.EnumSet;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_239;
import net.minecraft.class_2828;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public class MaceSpoofModule extends Module {

    private static final class_5321<class_1887> BREACH =
            class_5321.method_29179(class_7924.field_41265, class_2960.method_60654("minecraft:breach"));

    private static final class_5321<class_1887> DENSITY =
            class_5321.method_29179(class_7924.field_41265, class_2960.method_60654("minecraft:density"));

    private static final EnumSet<ResultType> HOTBAR_ONLY =
            EnumSet.of(ResultType.HOTBAR);

    private final Setting<Float> height = num(
            "SpoofHeight", 20.0f, 1.0f, 50.0f);

    private final Setting<Boolean> dtap = bool("DTap", false);

    private final Setting<Boolean> anySlot = bool("AnySlot", true);

    private final Setting<Integer> breachSlot = register(
            new Setting<>("BreachSlot", 1, 1, 9, v -> !anySlot.getValue()));

    private final Setting<Integer> densitySlot = register(
            new Setting<>("DensitySlot", 2, 1, 9, v -> !anySlot.getValue()));

    private class_1297 dtapTarget      = null;

    private Result dtapSecondMace  = null;

    private int    dtapSavedSlot   = -1;

    public MaceSpoofModule() {
        super("MaceSpoof",
              "Spoofs your fall height to instantly mace smash.",
              Category.EXPLOIT);
    }

    @Override
    public void onDisable() {
        clearDTapState();
    }

    @Subscribe
    public void onAttackPre(AttackEvent.Pre event) {
        if (nullCheck()) return;

        boolean entityTargeted = (mc.field_1765 != null
                && mc.field_1765.method_17783() == class_239.class_240.field_1331)
                || TriggerBotModule.overrideTarget != null;
        if (!entityTargeted) return;

        if (dtap.getValue()) {
            handleDTapPre();
        } else {

            if (mc.field_1724.method_6047().method_31574(class_1802.field_49814)) {
                sendSpoof();
            }
        }
    }

    @Subscribe
    public void onAttackPost(AttackEvent.Post event) {
        if (nullCheck()) return;
        if (!dtap.getValue()) return;
        if (dtapTarget == null || dtapSecondMace == null) return;

        class_1297 target     = dtapTarget;
        Result secondMace = dtapSecondMace;
        int    savedSlot  = dtapSavedSlot;
        clearDTapState();

        if (target.method_31481() || !target.method_5805()) {

            InventoryUtil.swap(savedSlot);
            return;
        }

        InventoryUtil.swap(secondMace);
        sendSpoof();
        mc.field_1761.method_2918(mc.field_1724, target);
        mc.field_1724.method_6104(class_1268.field_5808);

        InventoryUtil.swapBack(secondMace, savedSlot);
    }

    private void handleDTapPre() {
        Result breachMace;
        Result densityMace;

        if (anySlot.getValue()) {

            breachMace = InventoryUtil.find(
                    s -> !s.method_7960() && s.method_31574(class_1802.field_49814) && EnchantmentUtil.has(BREACH, s),
                    HOTBAR_ONLY);
            densityMace = InventoryUtil.find(
                    s -> !s.method_7960() && s.method_31574(class_1802.field_49814) && EnchantmentUtil.has(DENSITY, s),
                    HOTBAR_ONLY);
        } else {

            int bSlot = breachSlot.getValue() - 1;
            int dSlot = densitySlot.getValue() - 1;

            var bStack = mc.field_1724.method_31548().method_5438(bSlot);
            var dStack = mc.field_1724.method_31548().method_5438(dSlot);

            breachMace = (!bStack.method_7960() && bStack.method_31574(class_1802.field_49814) && EnchantmentUtil.has(BREACH, bStack))
                    ? new Result(bSlot, bStack, ResultType.HOTBAR)
                    : new Result(-1, net.minecraft.class_1799.field_8037, ResultType.NONE);

            densityMace = (!dStack.method_7960() && dStack.method_31574(class_1802.field_49814) && EnchantmentUtil.has(DENSITY, dStack))
                    ? new Result(dSlot, dStack, ResultType.HOTBAR)
                    : new Result(-1, net.minecraft.class_1799.field_8037, ResultType.NONE);
        }

        if (!breachMace.found() || !densityMace.found()
                || breachMace.slot() == densityMace.slot()) {

            if (mc.field_1724.method_6047().method_31574(class_1802.field_49814)) sendSpoof();
            return;
        }

        Result firstMace  = breachMace;
        Result secondMace = densityMace;

        dtapSavedSlot  = InventoryUtil.selected();
        dtapTarget     = TriggerBotModule.overrideTarget != null
                ? TriggerBotModule.overrideTarget
                : mc.field_1692;
        dtapSecondMace = secondMace;

        if (!firstMace.holding()) {
            InventoryUtil.swap(firstMace);
        }

        sendSpoof();
    }

    private void sendSpoof() {
        float h = height.getValue();

        for (int i = 0; i < 3; i++) {
            sendFakeY(0, false);
        }

        sendFakeY(h, false);

        sendFakeY(0, false);
    }

    private void sendFakeY(double offset, boolean onGround) {
        mc.field_1724.field_3944.method_52787(
                new class_2828.class_2829(
                        mc.field_1724.method_23317(),
                        mc.field_1724.method_23318() + offset,
                        mc.field_1724.method_23321(),
                        onGround,
                        mc.field_1724.field_5976));
    }

    private void clearDTapState() {
        dtapTarget     = null;
        dtapSecondMace = null;
        dtapSavedSlot  = -1;
    }
}
