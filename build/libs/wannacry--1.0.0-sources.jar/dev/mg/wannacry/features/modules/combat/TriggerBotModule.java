package dev.mg.wannacry.features.modules.combat;

import dev.mg.wannacry.event.impl.entity.player.TickEvent;
import dev.mg.wannacry.event.impl.input.AttackEvent;
import dev.mg.wannacry.event.system.Subscribe;
import dev.mg.wannacry.features.modules.Module;
import dev.mg.wannacry.features.settings.ItemWhitelist;
import dev.mg.wannacry.features.settings.ItemWhitelistHolder;
import dev.mg.wannacry.features.settings.Setting;
import dev.mg.wannacry.util.MouseSimulation;
import dev.mg.wannacry.util.ShieldUtils;
import dev.mg.wannacry.util.models.Timer;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1642;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1819;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import org.lwjgl.glfw.GLFW;

public class TriggerBotModule extends Module implements ItemWhitelistHolder {

    public static class_1297 overrideTarget = null;

    public static final String WHITELIST_SETTING = "HeldItemWhitelist";

    private static final String DEFAULT_WHITELIST =
            "minecraft:diamond_sword,minecraft:netherite_sword," +
            "minecraft:diamond_axe,minecraft:netherite_axe";

    private final Setting<Boolean> inScreen         = bool("WorkInScreen",          false);
    private final Setting<Boolean> whileUse         = bool("WhileUse",              false);
    private final Setting<Boolean> onLeftClick      = bool("OnLeftClick",           false);
    private final Setting<Boolean> checkShield      = bool("CheckShield",           false);
    private final Setting<Boolean> onlyCritSword    = bool("OnlyCritSword",         false);
    private final Setting<Boolean> onlyCritAxe      = bool("OnlyCritAxe",           false);
    private final Setting<Boolean> prioritizeCrit   = bool("PrioritizeCriticals",   false);
    private final Setting<Boolean> swing            = bool("SwingHand",             true);
    private final Setting<Boolean> whileAscend      = bool("WhileAscending",        false);
    private final Setting<Boolean> clickSimulation  = bool("ClickSimulation",       false);
    private final Setting<Boolean> strayBypass      = bool("StrayBypass",           false);
    private final Setting<Boolean> allEntities      = bool("AllEntities",           false);
    private final Setting<Boolean> useShield        = bool("UseShield",             false);
    private final Setting<Float>   shieldTime       = num( "ShieldTimeMs",          350f, 1f, 1000f);
    private final Setting<Boolean> sticky           = bool("SamePlayer",            false);
    private final Setting<Boolean> predictAttacks   = bool("PredictAttacks",        false);
    private final Setting<Float>   predictVariation = num( "PredictVariation",      0f,   0f, 10f);
    private final Setting<Boolean> enableMaceSwap   = bool("EnableMaceSwap",        false);

    private final Setting<String>  whitelistSetting = str(WHITELIST_SETTING, DEFAULT_WHITELIST);

    private final ItemWhitelist heldItemWhitelist = new ItemWhitelist();

    private final Timer shieldTimer = new Timer();

    private Thread           attackThread;
    private volatile boolean running  = false;
    private volatile boolean isFiring = false;

    private volatile class_1297 pendingTarget    = null;
    private volatile float  pendingThreshold = 1.0f;

    public TriggerBotModule() {
        super("TriggerBot", "Automatically attacks entities in your crosshair.", Category.CLOSET);

        heldItemWhitelist.deserialize(DEFAULT_WHITELIST);

        shieldTime      .setVisibility(v -> useShield.getValue());
        predictVariation.setVisibility(v -> predictAttacks.getValue());
    }

    @Override
    public ItemWhitelist getWhitelistFor(String settingName) {
        if (WHITELIST_SETTING.equals(settingName)) return heldItemWhitelist;
        return null;
    }

    private void syncWhitelistFromSetting() {
        heldItemWhitelist.deserialize(whitelistSetting.getValue());
    }

    @Override
    public void onLoad() {
        syncWhitelistFromSetting();
    }

    @Override
    public void onEnable() {
        running = true;
        attackThread = new Thread(this::attackLoop, "TriggerBot-Thread");
        attackThread.setDaemon(true);
        attackThread.start();
    }

    @Override
    public void onDisable() {
        running = false;
        isFiring = false;
        pendingTarget = null;
        if (attackThread != null) {
            attackThread.interrupt();
            attackThread = null;
        }
    }

    private void attackLoop() {
        while (running) {
            try {
                poll();
                Thread.sleep(1);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            } catch (Exception ignored) {}
        }
    }

    private void poll() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;

        if (!inScreen.getValue() && mc.field_1755 != null) return;
        if (onLeftClick.getValue() && !isMouseDown(mc, GLFW.GLFW_MOUSE_BUTTON_LEFT)) return;
        if (!whileUse.getValue() && isMouseDown(mc, GLFW.GLFW_MOUSE_BUTTON_RIGHT)) return;
        if (!whileAscend.getValue() && isAscending(mc)) return;
        if (isFiring) return;

        float baseThreshold = predictAttacks.getValue() ? 0.9f : 1.0f;
        float variation     = predictAttacks.getValue() ? (predictVariation.getValue() / 100.0f) : 0f;
        float threshold     = variation > 0f
                ? baseThreshold + (float) (Math.random() * variation)
                : baseThreshold;
        if (mc.field_1724.method_7261(0f) < threshold) return;

        if (!(mc.field_1765 instanceof class_3966 hit)) return;
        class_1297 entity = hit.method_17782();
        if (entity == null) return;

        if (sticky.getValue()) {
            class_1297 lastHurt = mc.field_1724.method_6052();
            if (lastHurt != null && entity != lastHurt) return;
        }

        if (!isValidTarget(entity)) return;

        if (entity instanceof class_1657 player
                && checkShield.getValue()
                && ShieldUtils.isShielding(player)) return;

        class_1799 heldItem = mc.field_1724.method_6047();
        if (!heldItemWhitelist.isAllowed(heldItem)) return;

        boolean heldSword = heldItem.method_31573(net.minecraft.class_3489.field_42611);
        boolean heldAxe   = heldItem.method_7909() instanceof net.minecraft.class_1743;

        if (heldSword) {
            if (onlyCritSword.getValue()  && !isFalling(mc))   return;
            if (prioritizeCrit.getValue() && !isCritReady(mc) && !mc.field_1724.method_24828()) return;
        }
        if (heldAxe) {
            if (onlyCritAxe.getValue()    && !isFalling(mc))   return;
            if (prioritizeCrit.getValue() && !isCritReady(mc) && !mc.field_1724.method_24828()) return;
        }

        tryHit(mc, entity, threshold);
    }

    private void tryHit(class_310 mc, class_1297 entity, float threshold) {

        isFiring         = true;
        pendingThreshold = threshold;
        pendingTarget    = entity;
    }

    @Subscribe
    public void onPreTick(TickEvent.Pre event) {
        class_1297 entity = pendingTarget;
        if (entity == null) return;

        pendingTarget = null;
        float threshold = pendingThreshold;

        if (mc.field_1724 == null || mc.field_1761 == null) { isFiring = false; return; }

        if (mc.field_1724.method_7261(0f) < threshold) { isFiring = false; return; }

        if (!(mc.field_1765 instanceof class_3966 currentHit)
                || currentHit.method_17782() != entity) { isFiring = false; return; }

        if (!isValidTarget(entity)) { isFiring = false; return; }

        if (entity instanceof class_1657 player
                && checkShield.getValue()
                && ShieldUtils.isShielding(player)) { isFiring = false; return; }

        if (!heldItemWhitelist.isAllowed(mc.field_1724.method_6047())) { isFiring = false; return; }

        boolean doMaceSwap   = enableMaceSwap.getValue();
        boolean doSwing      = swing.getValue();
        boolean doClick      = clickSimulation.getValue();
        boolean doShield     = useShield.getValue();
        int     shieldHoldMs = shieldTime.getValue().intValue();

        if (doShield
                && mc.field_1724.method_6079().method_7909() instanceof class_1819
                && mc.field_1724.method_6039()) {
            MouseSimulation.mouseRelease(GLFW.GLFW_MOUSE_BUTTON_RIGHT);
        }

        if (doMaceSwap) {

            TriggerBotModule.overrideTarget = entity;
            try {
                EVENT_BUS.post(new AttackEvent.Pre());
                mc.field_1761.method_2918(mc.field_1724, entity);
                if (doSwing) mc.field_1724.method_6104(class_1268.field_5808);
                EVENT_BUS.post(new AttackEvent.Post());
            } finally {
                TriggerBotModule.overrideTarget = null;
            }
        } else {
            mc.field_1761.method_2918(mc.field_1724, entity);
            if (doSwing) mc.field_1724.method_6104(class_1268.field_5808);
        }

        isFiring = false;

        if (doClick) MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_LEFT);

        shieldTimer.reset();

        if (doShield
                && mc.field_1724.method_6079().method_7909() == class_1802.field_8255
                && !mc.field_1724.method_6039()) {
            if (!shieldTimer.passedMs(shieldHoldMs)) {
                MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_RIGHT, shieldHoldMs);
                shieldTimer.reset();
            }
        }
    }

    @Subscribe
    public void onAttackPre(AttackEvent.Pre event) {
        if (isFiring) return;
        if (!isMouseDown(mc, GLFW.GLFW_MOUSE_BUTTON_LEFT)) {
            event.cancel();
        }
    }

    private boolean isValidTarget(class_1297 entity) {
        if (allEntities.getValue()) return entity != null;
        if (strayBypass.getValue() && entity instanceof class_1642) return true;
        return entity instanceof class_1657;
    }

    private static boolean isMouseDown(class_310 mc, int button) {
        return GLFW.glfwGetMouseButton(mc.method_22683().method_4490(), button) == GLFW.GLFW_PRESS;
    }

    private static boolean isAscending(class_310 mc) {
        return mc.field_1724 != null && !mc.field_1724.method_24828() && mc.field_1724.method_18798().field_1351 > 0;
    }

    private static boolean isFalling(class_310 mc) {
        return mc.field_1724 != null && !mc.field_1724.method_24828() && mc.field_1724.method_18798().field_1351 < 0;
    }

    private static boolean isCritReady(class_310 mc) {
        return mc.field_1724 != null
                && !mc.field_1724.method_24828()
                && mc.field_1724.method_18798().field_1351 < 0
                && mc.field_1724.field_6017 > 0;
    }
}
