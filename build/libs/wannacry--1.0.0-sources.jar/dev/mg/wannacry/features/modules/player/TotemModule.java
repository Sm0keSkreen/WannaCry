package dev.mg.wannacry.features.modules.player;

import dev.mg.wannacry.Satellite;
import dev.mg.wannacry.event.impl.entity.player.TickEvent;
import dev.mg.wannacry.event.system.Subscribe;
import dev.mg.wannacry.features.modules.Module;
import dev.mg.wannacry.features.modules.exploit.XCarryModule;
import dev.mg.wannacry.features.settings.Setting;
import dev.mg.wannacry.util.inventory.InventoryUtil;
import dev.mg.wannacry.util.inventory.Result;
import dev.mg.wannacry.util.inventory.ResultType;
import dev.mg.wannacry.util.models.Timer;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_465;
import net.minecraft.class_490;

public class TotemModule extends Module {

    public enum Mode {
        FULL,
        INVENTORY,
        HOVER
    }

    private final Setting<Mode>    mode          = mode("Mode",           Mode.FULL);

    private final Setting<Float>   delayMs       = num( "DelayMs",        50f, 0f, 500f);

    private final Setting<Boolean> autoOpen      = bool("AutoOpen",       false);

    private final Setting<Boolean> autoClose     = bool("AutoClose",      false);

    private final Setting<Boolean> hotbarFill    = bool("HotbarFill",     false);

    private final Setting<Boolean> xcarryCrafting = bool("XCarryCrafting", true);

    private final Timer fullTimer = new Timer();

    private boolean autoOpenedInventory = false;

    private boolean justPlacedTotem = false;

    public TotemModule() {
        super("Totem",
              "Helps with toteming quickly. Full: auto totem. " +
              "Inventory: auto totem only while the inventory is open. " +
              "Hover: offhands/hotbar fills instantly when hovered over. " +
              "XCarry: also pulls totems from the crafting grid when XCarry is active.",
              Category.CLOSET);

        delayMs       .setVisibility(v -> mode.getValue() == Mode.FULL || mode.getValue() == Mode.INVENTORY);
        autoOpen      .setVisibility(v -> mode.getValue() == Mode.INVENTORY);
        autoClose     .setVisibility(v -> mode.getValue() == Mode.INVENTORY);
        hotbarFill    .setVisibility(v -> mode.getValue() == Mode.HOVER);
        xcarryCrafting.setVisibility(v -> mode.getValue() == Mode.FULL || mode.getValue() == Mode.INVENTORY);
    }

    @Override
    public void onEnable() {
        fullTimer.reset();
        autoOpenedInventory = false;
        justPlacedTotem     = false;
    }

    @Override
    public void onDisable() {

        if (autoOpenedInventory && mc.field_1724 != null && mc.field_1755 instanceof class_490) {
            mc.field_1724.method_7346();
        }
        autoOpenedInventory = false;
        justPlacedTotem     = false;
    }

    @Subscribe
    public void onTick(TickEvent.Pre event) {
        if (nullCheck()) return;

        switch (mode.getValue()) {
            case FULL, INVENTORY -> {
                if (!fullTimer.passedMs(delayMs.getValue().longValue())) return;
                fullTimer.reset();
                if (mode.getValue() == Mode.FULL) tickFull();
                else                              tickInventory();
            }
            case HOVER -> tickHover();
        }
    }

    private void tickFull() {
        if (mc.field_1755 != null && !(mc.field_1755 instanceof class_490)) return;
        if (mc.field_1724.method_6079().method_31574(class_1802.field_8288)) return;

        Result result = InventoryUtil.find(class_1802.field_8288, InventoryUtil.FULL_SCOPE);
        if (result.found() && result.type() != ResultType.OFFHAND) {
            InventoryUtil.click(toContainerSlot(result), 40, class_1713.field_7791);
            return;
        }

        if (xcarryCrafting.getValue() && isXCarryEnabled()) {
            int craftingSlot = findTotemInCraftingGrid();
            if (craftingSlot != -1) {
                InventoryUtil.click(craftingSlot, 40, class_1713.field_7791);
            }
        }
    }

    private void tickInventory() {

        if (mc.field_1755 != null && !(mc.field_1755 instanceof class_490)) return;

        boolean totemInOffhand = mc.field_1724.method_6079().method_31574(class_1802.field_8288);

        if (justPlacedTotem && totemInOffhand) {
            justPlacedTotem     = false;
            autoOpenedInventory = false;
            if (autoClose.getValue() && mc.field_1755 instanceof class_490) {
                mc.field_1724.method_7346();
            }
            return;
        }

        if (totemInOffhand) {
            justPlacedTotem     = false;
            autoOpenedInventory = false;
            return;
        }

        if (justPlacedTotem) return;

        Result result = InventoryUtil.find(class_1802.field_8288, InventoryUtil.INVENTORY_SCOPE);
        if (!result.found() || result.type() == ResultType.OFFHAND) {
            result = InventoryUtil.find(class_1802.field_8288, InventoryUtil.HOTBAR_SCOPE);
        }

        boolean foundInNormalSlots = result.found() && result.type() != ResultType.OFFHAND;

        int craftingSlot = -1;
        if (!foundInNormalSlots && xcarryCrafting.getValue() && isXCarryEnabled()) {
            craftingSlot = findTotemInCraftingGrid();
        }

        if (!foundInNormalSlots && craftingSlot == -1) {

            return;
        }

        if (!(mc.field_1755 instanceof class_490)) {

            if (autoOpen.getValue() && !autoOpenedInventory) {
                mc.method_1507(new class_490(mc.field_1724));
                autoOpenedInventory = true;
            }
            return;
        }

        if (foundInNormalSlots) {
            InventoryUtil.click(toContainerSlot(result), 40, class_1713.field_7791);
        } else {

            InventoryUtil.click(craftingSlot, 40, class_1713.field_7791);
        }
        justPlacedTotem = true;
    }

    private void tickHover() {
        if (!(mc.field_1755 instanceof class_465<?> screen)) return;

        class_1735 hoveredSlot = screen.field_2787;
        if (hoveredSlot == null || !hoveredSlot.method_7681()) return;
        if (!hoveredSlot.method_7677().method_31574(class_1802.field_8288)) return;

        if (!mc.field_1724.method_6079().method_31574(class_1802.field_8288)) {

            InventoryUtil.click(hoveredSlot.field_7874, 40, class_1713.field_7791);
            return;
        }

        if (!hotbarFill.getValue()) return;

        if (hoveredSlot.field_7874 == 45) return;

        if (hoveredSlot.field_7874 >= 36 && hoveredSlot.field_7874 <= 44) return;

        int emptySlot = findEmptyHotbarSlot();
        if (emptySlot == -1) return;

        InventoryUtil.click(hoveredSlot.field_7874, emptySlot, class_1713.field_7791);
    }

    private int findTotemInCraftingGrid() {

        for (int containerSlot = 1; containerSlot <= 4; containerSlot++) {
            net.minecraft.class_1735 slot =
                    mc.field_1724.field_7498.method_7611(containerSlot);
            if (slot != null && slot.method_7681()
                    && slot.method_7677().method_31574(class_1802.field_8288)) {
                return containerSlot;
            }
        }
        return -1;
    }

    private boolean isXCarryEnabled() {
        XCarryModule xcarry = Satellite.moduleManager.getModuleByClass(XCarryModule.class);
        return xcarry != null && xcarry.isEnabled();
    }

    private int findEmptyHotbarSlot() {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (stack.method_7960()) return i;
        }
        return -1;
    }

    private static int toContainerSlot(Result result) {
        return result.type() == ResultType.HOTBAR ? result.slot() + 36 : result.slot();
    }

    @Override
    public String getDisplayInfo() {
        return switch (mode.getValue()) {
            case FULL     -> "Full";
            case INVENTORY -> {
                if (autoOpen.getValue() && autoClose.getValue()) yield "Inv+AC";
                if (autoOpen.getValue())  yield "Inv+Open";
                if (autoClose.getValue()) yield "Inv+Close";
                yield "Inventory";
            }
            case HOVER    -> hotbarFill.getValue() ? "Hover+Fill" : "Hover";
        };
    }
}
