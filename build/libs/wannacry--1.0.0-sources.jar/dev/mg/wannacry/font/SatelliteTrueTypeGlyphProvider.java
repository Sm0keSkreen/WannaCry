package dev.mg.wannacry.font;

import com.mojang.blaze3d.font.*;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import it.unimi.dsi.fastutil.ints.IntArraySet;
import it.unimi.dsi.fastutil.ints.IntSet;
import org.jspecify.annotations.Nullable;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.util.freetype.*;

import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.util.Locale;
import net.minecraft.class_1011;
import net.minecraft.class_11759;
import net.minecraft.class_11768;
import net.minecraft.class_379;
import net.minecraft.class_383;
import net.minecraft.class_384;
import net.minecraft.class_390;
import net.minecraft.class_8532;
import net.minecraft.class_9111;

public class SatelliteTrueTypeGlyphProvider implements class_390 {

    @Nullable
    private ByteBuffer fontMemory;
    @Nullable
    private FT_Face face;
    public final float oversample;
    private final int ftLoadFlags;
    private final int ftRenderMode;

    private final class_8532<GlyphEntry> glyphs =
            new class_8532<>(GlyphEntry[]::new, GlyphEntry[][]::new);

    public SatelliteTrueTypeGlyphProvider(ByteBuffer byteBuffer, FT_Face ftFace, float size, float oversample,
                                           float shiftX, float shiftY, String skip,
                                           int ftLoadFlags, int ftRenderMode) {
        this.fontMemory = byteBuffer;
        this.face = ftFace;
        this.oversample = oversample;
        this.ftLoadFlags = ftLoadFlags;
        this.ftRenderMode = ftRenderMode;

        IntSet skipSet = new IntArraySet();
        skip.codePoints().forEach(skipSet::add);

        int pixelSize = Math.round(size * oversample);
        FreeType.FT_Set_Pixel_Sizes(ftFace, pixelSize, pixelSize);

        float tx = shiftX * oversample;
        float ty = -shiftY * oversample;

        try (MemoryStack stack = MemoryStack.stackPush()) {
            FT_Vector vec = class_9111.method_56147(FT_Vector.malloc(stack), tx, ty);
            FreeType.FT_Set_Transform(ftFace, null, vec);

            IntBuffer glyphIndexBuffer = stack.mallocInt(1);
            int codepoint = (int) FreeType.FT_Get_First_Char(ftFace, glyphIndexBuffer);

            while (true) {
                int glyphIndex = glyphIndexBuffer.get(0);
                if (glyphIndex == 0) return;

                if (!skipSet.contains(codepoint)) {
                    this.glyphs.method_51599(codepoint, new GlyphEntry(glyphIndex));
                }

                codepoint = (int) FreeType.FT_Get_Next_Char(ftFace, codepoint, glyphIndexBuffer);
            }
        }
    }

    @Nullable
    @Override
    public class_11759 method_2040(int codepoint) {
        GlyphEntry entry = this.glyphs.method_51598(codepoint);
        return entry != null ? this.getOrLoadGlyph(codepoint, entry) : null;
    }

    private class_11759 getOrLoadGlyph(int codepoint, GlyphEntry entry) {
        class_11759 glyph = entry.glyph;
        if (glyph == null) {
            FT_Face ftFace = this.validateFontOpen();
            synchronized (ftFace) {
                glyph = entry.glyph;
                if (glyph == null) {
                    glyph = this.loadGlyph(codepoint, ftFace, entry.index);
                    entry.glyph = glyph;
                }
            }
        }
        return glyph;
    }

    private class_11759 loadGlyph(int codepoint, FT_Face ftFace, int glyphIndex) {
        int err = FreeType.FT_Load_Glyph(ftFace, glyphIndex, this.ftLoadFlags);
        if (err != 0) {
            class_9111.method_59837(err, String.format(Locale.ROOT, "Loading glyph U+%06X", codepoint));
        }

        FT_GlyphSlot slot = ftFace.glyph();
        if (slot == null) {
            throw new NullPointerException(String.format(Locale.ROOT, "Glyph U+%06X not initialized", codepoint));
        }

        float advance = class_9111.method_56146(slot.advance());

        FT_Bitmap bmp = slot.bitmap();
        int left = slot.bitmap_left();
        int top  = slot.bitmap_top();
        int w    = bmp.width();
        int h    = bmp.rows();

        if (w <= 0 || h <= 0) {
            return new class_384(advance / this.oversample);
        }

        return new Glyph(left, top, w, h, advance, glyphIndex);
    }

    FT_Face validateFontOpen() {
        if (this.fontMemory != null && this.face != null) return this.face;
        throw new IllegalStateException("Provider already closed");
    }

    @Override
    public void close() {
        if (this.face != null) {
            synchronized (class_9111.field_51483) {
                class_9111.method_56145(FreeType.FT_Done_Face(this.face), "Deleting face");
            }
            this.face = null;
        }
        MemoryUtil.memFree(this.fontMemory);
        this.fontMemory = null;
    }

    @Override
    public IntSet method_27442() {
        return this.glyphs.method_51603();
    }

    class Glyph implements class_11759 {
        final int width;
        final int height;
        final float bearingX;
        final float bearingY;
        final class_379 info;
        final int index;

        Glyph(float left, float top, int w, int h, float advance, int index) {
            this.width    = w;
            this.height   = h;
            this.bearingX = left / SatelliteTrueTypeGlyphProvider.this.oversample;
            this.bearingY = top  / SatelliteTrueTypeGlyphProvider.this.oversample;
            this.info     = class_379.method_73329(advance / SatelliteTrueTypeGlyphProvider.this.oversample);
            this.index    = index;
        }

        @Override
        public class_379 method_73331() {
            return this.info;
        }

        @Override
        public class_11768 method_73332(class_11759.class_11760 stitcher) {
            return stitcher.method_73334(this.info, new class_383() {

                @Override public int   method_2031()  { return Glyph.this.width; }
                @Override public int   method_2032() { return Glyph.this.height; }
                @Override public float method_2035()  { return SatelliteTrueTypeGlyphProvider.this.oversample; }
                @Override public float method_56129() { return Glyph.this.bearingX; }
                @Override public float method_56130()  { return Glyph.this.bearingY; }
                @Override public boolean method_2033()    { return false; }

                @Override
                public void method_2030(int x, int y, GpuTexture gpuTexture) {
                    FT_Face ftFace = SatelliteTrueTypeGlyphProvider.this.validateFontOpen();
                    synchronized (ftFace) {
                        int err = FreeType.FT_Load_Glyph(ftFace, Glyph.this.index,
                                SatelliteTrueTypeGlyphProvider.this.ftLoadFlags);
                        if (err != 0) {
                            class_9111.method_59837(err, "Reloading glyph index " + Glyph.this.index);
                        }

                        FT_GlyphSlot slot = ftFace.glyph();
                        if (slot == null) {
                            throw new IllegalStateException("Glyph slot is null for index " + Glyph.this.index);
                        }

                        err = FreeType.FT_Render_Glyph(slot, SatelliteTrueTypeGlyphProvider.this.ftRenderMode);
                        if (err != 0) {
                            class_9111.method_59837(err, "Rendering glyph index " + Glyph.this.index);
                        }

                        FT_Bitmap bitmap = slot.bitmap();
                        int bw    = bitmap.width();
                        int bh    = bitmap.rows();
                        if (bw <= 0 || bh <= 0) return;

                        int pitch  = bitmap.pitch();
                        ByteBuffer src = bitmap.buffer(pitch * bh);

                        try (class_1011 img = new class_1011(class_1011.class_1012.field_4998, bw, bh, false)) {
                            long dstPtr = img.method_67769();
                            for (int row = 0; row < bh; row++) {
                                long dstRow = dstPtr + (long) row * bw;
                                long srcRow = MemoryUtil.memAddress(src) + (long) row * pitch;
                                MemoryUtil.memCopy(srcRow, dstRow, bw);
                            }
                            RenderSystem.getDevice()
                                    .createCommandEncoder()
                                    .writeToTexture(gpuTexture, img, 0, 0, x, y, bw, bh, 0, 0);
                        }
                    }
                }
            });
        }
    }

    static class GlyphEntry {
        final int index;
        @Nullable volatile class_11759 glyph;

        GlyphEntry(int index) {
            this.index = index;
        }
    }
}
