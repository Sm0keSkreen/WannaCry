package dev.mg.wannacry.font;

import dev.mg.wannacry.Satellite;
import dev.mg.wannacry.features.modules.client.FontModule;
import org.lwjgl.util.freetype.FreeType;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_11642;
import net.minecraft.class_2960;
import net.minecraft.class_377;
import net.minecraft.class_390;
import net.minecraft.class_9243;

import static dev.mg.wannacry.util.traits.Util.mc;

public class FontLoader {

    private class_377 storage;
    private int       currentSize       = -1;
    private int       currentOversample = -1;
    private FontType  lastFont          = null;
    private int       currentFlags      = -1;
    private int       currentRenderMode = -1;
    private float     currentShiftX     = Float.NaN;
    private float     currentShiftY     = Float.NaN;

    public void init() {
        FontModule fontModule = Satellite.moduleManager.getModuleByClass(FontModule.class);
        if (fontModule == null) return;

        int      newSize      = fontModule.glyphSize.getValue();
        int      newOversample = fontModule.oversample.getValue();
        FontType selectedFont = fontModule.fontType.getValue();
        float    shiftX       = fontModule.shiftX.getValue();
        float    shiftY       = fontModule.shiftY.getValue();

        int renderMode = switch (fontModule.antialiasMode.getValue()) {
            case LIGHT -> FreeType.FT_RENDER_MODE_LIGHT;
            default    -> FreeType.FT_RENDER_MODE_NORMAL;
        };

        int flags = FreeType.FT_LOAD_DEFAULT | (renderMode << 16);
        if (fontModule.autoHint.getValue()) flags |= FreeType.FT_LOAD_FORCE_AUTOHINT;

        if (storage != null
                && currentSize       == newSize
                && currentOversample == newOversample
                && selectedFont      == lastFont
                && currentFlags      == flags
                && currentRenderMode == renderMode
                && Float.compare(currentShiftX, shiftX) == 0
                && Float.compare(currentShiftY, shiftY) == 0) {
            return;
        }

        SatelliteTrueTypeGlyphProviderDefinition definition =
                new SatelliteTrueTypeGlyphProviderDefinition(
                        class_2960.method_60655("wannacry", selectedFont.getFileName()),
                        newSize, newOversample,
                        shiftX, shiftY,
                        "",
                        flags, renderMode);

        try {
            class_390 font = definition.method_51734().orThrow().load(mc.method_1478());

            class_11642 stitcher = new class_11642(
                    mc.method_1531(),
                    class_2960.method_60655("wannacry", selectedFont.getFileName() + "_storage"));

            storage = new class_377(stitcher);
            storage.method_2004(
                    List.of(new class_390.class_9241(font, class_9243.class_9244.field_49118)),
                    Collections.emptySet());

            currentSize       = newSize;
            currentOversample = newOversample;
            currentFlags      = flags;
            currentRenderMode = renderMode;
            currentShiftX     = shiftX;
            currentShiftY     = shiftY;
            lastFont          = selectedFont;

        } catch (IOException e) {
            Satellite.LOGGER.error("[FontLoader] Failed to load font '{}': {}", selectedFont.getFileName(), e.getMessage());
            storage           = null;
            currentSize       = -1;
            currentOversample = -1;
            lastFont          = null;
            currentFlags      = -1;
            currentRenderMode = -1;
            currentShiftX     = Float.NaN;
            currentShiftY     = Float.NaN;
        }
    }

    public class_377 getStorage()           { return storage; }
    public int     getCurrentSize()       { return currentSize; }
    public int     getCurrentOversample() { return currentOversample; }
}
