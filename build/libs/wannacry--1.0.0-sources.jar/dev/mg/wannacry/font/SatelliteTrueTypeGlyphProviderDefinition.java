package dev.mg.wannacry.font;

import com.mojang.blaze3d.platform.TextureUtil;
import com.mojang.datafixers.util.Either;
import org.lwjgl.PointerBuffer;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.util.freetype.FT_Face;
import org.lwjgl.util.freetype.FreeType;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_389;
import net.minecraft.class_390;
import net.minecraft.class_394;
import net.minecraft.class_9111;

public record SatelliteTrueTypeGlyphProviderDefinition(
        class_2960 location,
        float size,
        float oversample,
        float shiftX,
        float shiftY,
        String skip,
        int ftLoadFlags,
        int ftRenderMode
) implements class_389 {

    @Override
    public class_394 method_51731() {
        return class_394.field_2317;
    }

    @Override
    public Either<class_8539, class_8540> method_51734() {
        return Either.left(this::load);
    }

    private class_390 load(class_3300 resourceManager) throws IOException {
        FT_Face face = null;
        ByteBuffer buf = null;

        try {
            InputStream inputStream = resourceManager.open(this.location.method_45138("font/"));
            try {
                buf = TextureUtil.readResource(inputStream);

                synchronized (class_9111.field_51483) {
                    try (MemoryStack stack = MemoryStack.stackPush()) {
                        PointerBuffer pb = stack.mallocPointer(1);
                        class_9111.method_59837(
                                FreeType.FT_New_Memory_Face(class_9111.method_56143(), buf, 0L, pb),
                                "Initializing font face");
                        face = FT_Face.create(pb.get());
                    }

                    String format = FreeType.FT_Get_Font_Format(face);
                    if (!"TrueType".equals(format) && !"CFF".equals(format) && !"OpenType".equals(format)) {
                        throw new IOException("Font is not TrueType/OpenType, was " + format);
                    }

                    class_9111.method_59837(
                            FreeType.FT_Select_Charmap(face, FreeType.FT_ENCODING_UNICODE),
                            "Find unicode charmap");

                    return new SatelliteTrueTypeGlyphProvider(
                            buf, face,
                            this.size, this.oversample,
                            this.shiftX, this.shiftY,
                            this.skip,
                            this.ftLoadFlags, this.ftRenderMode);
                }
            } finally {
                inputStream.close();
            }
        } catch (Exception e) {
            synchronized (class_9111.field_51483) {
                if (face != null) FreeType.FT_Done_Face(face);
            }
            if (buf != null) MemoryUtil.memFree(buf);
            throw e;
        }
    }
}
