package dev.mg.wannacry.font;

import dev.mg.wannacry.mixin.render.gui.MixinFont;
import net.minecraft.class_11603;
import net.minecraft.class_11719;
import net.minecraft.class_11769;
import net.minecraft.class_327;

import static dev.mg.wannacry.util.traits.Util.mc;

public class FontRendererProvider {

    private final FontLoader fontLoader;
    private class_327 cachedRenderer;
    private int  cachedSize       = -1;
    private int  cachedOversample = -1;

    public FontRendererProvider(FontLoader fontLoader) {
        this.fontLoader = fontLoader;
    }

    public class_327 getRenderer(boolean enabled) {
        if (!enabled) {

            cachedRenderer  = null;
            cachedSize      = -1;
            cachedOversample = -1;
            return mc.field_1772;
        }

        fontLoader.init();

        if (cachedRenderer != null
                && cachedSize       == fontLoader.getCurrentSize()
                && cachedOversample == fontLoader.getCurrentOversample()) {
            return cachedRenderer;
        }

        class_11769 rectangle = ((MixinFont) mc.field_1772).getProvider().method_73366();

        cachedRenderer = new class_327(new class_327.class_11602() {
            @Override
            public class_11603 method_72735(class_11719 font) {
                return fontLoader.getStorage().method_72788(true);
            }

            @Override
            public class_11769 method_73366() {
                return rectangle;
            }
        });

        cachedSize       = fontLoader.getCurrentSize();
        cachedOversample = fontLoader.getCurrentOversample();

        return cachedRenderer;
    }
}
