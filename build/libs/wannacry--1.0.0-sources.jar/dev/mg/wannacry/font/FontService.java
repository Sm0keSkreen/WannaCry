package dev.mg.wannacry.font;

import dev.mg.wannacry.Satellite;
import dev.mg.wannacry.features.modules.client.FontModule;
import java.awt.Color;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;

import static dev.mg.wannacry.util.traits.Util.mc;

public class FontService {

    public final FontLoader          fontLoader       = new FontLoader();
    public final FontRendererProvider rendererProvider = new FontRendererProvider(fontLoader);

    private FontModule fontModule() {
        return Satellite.moduleManager.getModuleByClass(FontModule.class);
    }

    private boolean isEnabled() {
        FontModule m = fontModule();
        return m != null && m.isEnabled();
    }

    private int darken(int argb, int percent) {
        float factor = 1f - percent / 100f;
        int a = (argb >> 24) & 0xFF;
        int r = (int) (((argb >> 16) & 0xFF) * factor);
        int g = (int) (((argb >>  8) & 0xFF) * factor);
        int b = (int) ((argb         & 0xFF) * factor);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private int shadowColor(int color) {
        FontModule m = fontModule();
        int darken = m != null ? m.shadowDarken.getValue() : 70;
        return darken(color, darken);
    }

    private static final float SHADOW_TRANSLATE = 0.50f;

    public class_327 getFont() {
        return rendererProvider.getRenderer(isEnabled());
    }

    public void drawText(class_332 ctx, String text, int x, int y, int color, boolean shadow) {
        class_327 renderer = getFont();
        if (shadow) {
            var matrices = ctx.method_51448();
            matrices.pushMatrix();
            matrices.translate(SHADOW_TRANSLATE, SHADOW_TRANSLATE);
            ctx.method_51433(renderer, text, x, y, shadowColor(color), false);
            matrices.popMatrix();
        }
        ctx.method_51433(renderer, text, x, y, color, renderer.equals(mc.field_1772));
    }

    public void drawText(class_332 ctx, String text, int x, int y, boolean shadow) {
        drawText(ctx, text, x, y, 0xFFFFFFFF, shadow);
    }

    public void drawText(class_332 ctx, class_2561 text, int x, int y, int color, boolean shadow) {
        class_327 renderer = getFont();
        if (shadow) {
            var matrices = ctx.method_51448();
            matrices.pushMatrix();
            matrices.translate(SHADOW_TRANSLATE, SHADOW_TRANSLATE);
            ctx.method_51439(renderer, text, x, y, shadowColor(color), false);
            matrices.popMatrix();
        }
        ctx.method_51439(renderer, text, x, y, color, renderer.equals(mc.field_1772));
    }

    public void drawText(class_332 ctx, class_2561 text, int x, int y, boolean shadow) {
        drawText(ctx, text, x, y, 0xFFFFFFFF, shadow);
    }

    public int getWidth(String text) {
        return getFont().method_1727(text);
    }

    public int getWidth(class_2561 text) {
        return getFont().method_27525(text);
    }

    public int getHeight() {
        if (!isEnabled()) return mc.field_1772.field_2000;
        FontModule m = fontModule();
        return m != null ? Math.round(m.glyphSize.getValue() * 0.85f) : mc.field_1772.field_2000;
    }
}
