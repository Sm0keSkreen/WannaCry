package dev.mg.wannacry.ducks.render;

import net.minecraft.class_276;

public interface ILevelRenderer {
    void satellite$pushEntityOutlineFramebuffer(class_276 framebuffer);
    void satellite$popEntityOutlineFramebuffer();
}
