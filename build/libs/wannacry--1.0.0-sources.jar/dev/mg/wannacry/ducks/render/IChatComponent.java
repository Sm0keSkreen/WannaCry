package dev.mg.wannacry.ducks.render;

import net.minecraft.class_303;
import net.minecraft.class_7469;

public interface IChatComponent {
    void satellite$addMessage(class_303 message);
    void satellite$removeMessage(class_7469 signature);
}
