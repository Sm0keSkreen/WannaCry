package dev.mg.wannacry.ducks.render;

import net.minecraft.class_1297;
import org.jetbrains.annotations.Nullable;

public interface IEntityRenderState {
    @Nullable class_1297 satellite$getEntity();
    void satellite$setEntity(class_1297 entity);
}
