package dev.mg.wannacry.manager;

import dev.mg.wannacry.features.Feature;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1657;

public class SpeedManager extends Feature {
    private static final int SPEED_NORMALIZATION = 20;

    private final List<Float> localSpeed = new ArrayList<>();
    private float localSpeedNormal = 0f;

    public void update() {
        localSpeed.add(getCurrentSpeed(mc.field_1724));
        while (localSpeed.size() > SPEED_NORMALIZATION) localSpeed.removeFirst();

        localSpeedNormal = localSpeed.stream().reduce(0f, Float::sum) / localSpeed.size();
    }

    public double getSpeed(class_1657 player) {
        if (mc.field_1724 == player) return localSpeedNormal;
        return getCurrentSpeed(player);
    }

    public double getSpeedBpS(class_1657 player) {
        return getSpeed(player) * 20;
    }

    public double getSpeedKmH(class_1657 player) {
        return getSpeedBpS(player) * 3.6;
    }

    public float getCurrentSpeed(class_1297 entity) {
        class_1297 vehicle = entity.method_5854();
        double distTraveledX = entity.method_23317() - entity.field_6014;
        double distTraveledZ = entity.method_23321() - entity.field_5969;
        if (vehicle != null) {
            distTraveledX = vehicle.method_23317() - vehicle.field_6014;
            distTraveledZ = vehicle.method_23321() - vehicle.field_5969;
        }

        return  (float) Math.hypot(distTraveledX, distTraveledZ);
    }
}
