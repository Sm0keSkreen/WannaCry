package dev.mg.wannacry.manager;

import dev.mg.wannacry.event.Stage;
import dev.mg.wannacry.event.impl.entity.player.TickEvent;
import dev.mg.wannacry.event.impl.entity.player.TravelEvent;
import dev.mg.wannacry.event.impl.entity.player.UpdateWalkingPlayerEvent;
import dev.mg.wannacry.event.system.Subscribe;
import dev.mg.wannacry.util.models.Angles;
import dev.mg.wannacry.util.traits.Util;
import java.util.*;
import java.util.function.Predicate;
import net.minecraft.class_2828;
import net.minecraft.class_3532;

public class RotationManager implements Util {
    private final List<Callback> callbacks = new ArrayList<>();

    private boolean updateRender;
    private Angles renderSnapshot, renderSnapshot0;

    private Angles snapshot;
    private Angles travelSnapshot;

    private Angles rotLastSnapshot;

    public RotationManager() {
        EVENT_BUS.register(this);
    }

    @Subscribe(priority = 1000)
    public void onTickPre(TickEvent.Pre event) {
        executeCallbacks(callback -> callback.type() == Type.SYNC);
    }

    @Subscribe
    public void onTravelPre(TravelEvent.Pre event) {
        if (callbacks.isEmpty())
            return;

        Callback highest = callbacks.stream().max(Comparator.comparing(Callback::priority)).orElseThrow();
        if (highest.type() == Type.SYNC) {
            travelSnapshot = new Angles(mc.field_1724.method_36454(), mc.field_1724.method_36455());
            mc.field_1724.method_36456(highest.angles().yRot());
            mc.field_1724.method_36457(highest.angles().xRot());
        }
    }

    @Subscribe
    public void onTravelPost(TravelEvent.Post event) {
        if (travelSnapshot != null) {
            mc.field_1724.method_36456(travelSnapshot.yRot());
            mc.field_1724.method_36457(travelSnapshot.xRot());
            travelSnapshot = null;
        }
    }

    @Subscribe
    public void onUpdateWalking(UpdateWalkingPlayerEvent event) {
        if (event.getStage() == Stage.PRE) {
            if (callbacks.isEmpty()) {
                updateRenderSnapshot(new Angles(mc.field_1724.method_36454(), mc.field_1724.method_36455()), false);
                return;
            }
            Callback highest = callbacks.stream().max(Comparator.comparing(Callback::priority)).orElseThrow();

            updateRenderSnapshot(highest.angles(), true);

            snapshot        = new Angles(mc.field_1724.method_36454(), mc.field_1724.method_36455());
            rotLastSnapshot = new Angles(mc.field_1724.field_3941,  mc.field_1724.field_3925);

            mc.field_1724.method_36456(highest.angles().yRot());
            mc.field_1724.method_36457(highest.angles().xRot());
        } else if (snapshot != null) {
            executeCallbacks(callback -> callback.type() == Type.MOTION);

            mc.field_1724.method_36456(snapshot.yRot());
            mc.field_1724.method_36457(snapshot.xRot());

            if (rotLastSnapshot != null) {
                mc.field_1724.field_3941 = rotLastSnapshot.yRot();
                mc.field_1724.field_3925 = rotLastSnapshot.xRot();
                rotLastSnapshot = null;
            }

            snapshot = null;
        }
    }

    public void sync(Angles angles, Runnable runnable) {
        sync(angles, 0, runnable);
    }

    public void sync(Angles angles, int priority, Runnable runnable) {
        request(Type.SYNC, angles, priority, runnable);
    }

    public void motion(Angles angles, Runnable runnable) {
        motion(angles, 0, runnable);
    }

    public void motion(Angles angles, int priority, Runnable runnable) {
        request(Type.MOTION, angles, priority, runnable);
    }

    public void silent(Angles angles, Runnable runnable) {
        request(Type.SILENT, angles, 0, runnable);
    }

    public Angles getLerpRenderSnapshot(float lerp) {
        if (!updateRender) return null;
        return new Angles(
                class_3532.method_16439(lerp, renderSnapshot0.yRot(), renderSnapshot.yRot()),
                class_3532.method_16439(lerp, renderSnapshot0.xRot(), renderSnapshot.xRot())
        );
    }

    public void sendDuplicate(float yaw, float pitch) {
        mc.field_1724.field_3923 = 20;
        mc.field_1724.field_3941 = yaw;
        mc.field_1724.field_3925 = pitch;
        mc.field_1724.field_3944.method_52787(new class_2828.class_2830(
                mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(),
                yaw, pitch,
                mc.field_1724.method_24828(), mc.field_1724.field_5976
        ));
    }

    private void request(Type type, Angles angles, int priority, Runnable runnable) {
        Callback callback = new Callback(type, angles, priority, runnable);
        if (type == Type.SILENT) {
            sendDuplicate(angles.yRot(), angles.xRot());
            callback.execute();
        } else {
            callbacks.add(callback);
        }
    }

    private void executeCallbacks(Predicate<Callback> filter) {
        callbacks.removeIf(callback -> {
            if (filter.test(callback)) {
                callback.execute();
                return true;
            }
            return false;
        });
    }

    private void updateRenderSnapshot(Angles angles, boolean update) {
        this.renderSnapshot0 = this.renderSnapshot;
        this.renderSnapshot = angles;
        this.updateRender = update;

        if (renderSnapshot0 == null || renderSnapshot == null)
            return;

        if (class_3532.method_15379(renderSnapshot.yRot() - renderSnapshot0.yRot()) > 320) {
            this.renderSnapshot0 = this.renderSnapshot;
        }
    }

    record Callback(Type type, Angles angles, int priority, Runnable action) {
        public void execute() {
            if (action != null) action.run();
        }
    }

    public enum Type {
        MOTION,
        SYNC,
        SILENT
    }
}
