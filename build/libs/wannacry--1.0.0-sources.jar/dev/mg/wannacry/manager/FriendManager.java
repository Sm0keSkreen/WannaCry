package dev.mg.wannacry.manager;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.mg.wannacry.Satellite;
import dev.mg.wannacry.util.traits.Jsonable;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1657;

public class FriendManager implements Jsonable {
    private final List<String> friends = new ArrayList<>();

    public void init() {
        Satellite.configManager.addConfig(this);
    }

    public boolean isFriend(String name) {
        return this.friends.stream().anyMatch(friend -> friend.equalsIgnoreCase(name));
    }

    public boolean isFriend(class_1657 player) {
        return this.isFriend(player.method_7334().name());
    }

    public void addFriend(String name) {
        this.friends.add(name);
    }

    public void removeFriend(String name) {
        friends.removeIf(s -> s.equalsIgnoreCase(name));
    }

    public List<String> getFriends() {
        return this.friends;
    }

    @Override
    public JsonElement toJson() {
        JsonObject object = new JsonObject();
        JsonArray array = new JsonArray();
        for (String friend : friends) {
            array.add(friend);
        }
        object.add("friends", array);
        return object;
    }

    @Override
    public void fromJson(JsonElement element) {
        for (JsonElement e : element.getAsJsonObject().get("friends").getAsJsonArray()) {
            friends.add(e.getAsString());
        }
    }

    @Override
    public String getFileName() {
        return "friends.json";
    }
}
