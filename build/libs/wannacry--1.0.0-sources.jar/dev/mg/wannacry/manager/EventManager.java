package dev.mg.wannacry.manager;

import dev.mg.wannacry.Satellite;
import dev.mg.wannacry.event.Stage;
import dev.mg.wannacry.event.impl.entity.DeathEvent;
import dev.mg.wannacry.event.impl.entity.player.TickEvent;
import dev.mg.wannacry.event.impl.entity.player.UpdateWalkingPlayerEvent;
import dev.mg.wannacry.event.impl.input.KeyInputEvent;
import dev.mg.wannacry.event.impl.input.MouseInputEvent;
import dev.mg.wannacry.event.impl.network.ChatEvent;
import dev.mg.wannacry.event.impl.network.PacketEvent;
import dev.mg.wannacry.event.impl.render.Render2DEvent;
import dev.mg.wannacry.event.impl.render.Render3DEvent;
import dev.mg.wannacry.event.system.Subscribe;
import dev.mg.wannacry.features.Feature;
import net.minecraft.class_1657;
import net.minecraft.class_2658;
import net.minecraft.class_2761;
import net.minecraft.class_8709;
import net.minecraft.class_8710;

public class EventManager extends Feature {
    public void init() {
        EVENT_BUS.register(this);
    }

    public void onUnload() {
        EVENT_BUS.unregister(this);
    }

    @Subscribe
    public void onTick(TickEvent.Post event) {
        if (nullCheck())
            return;
        Satellite.moduleManager.onTick();
        for (class_1657 player : mc.field_1687.method_18456()) {
            if (player == null || player.method_6032() > 0.0F)
                continue;
            EVENT_BUS.post(new DeathEvent(player));
        }
    }

    @Subscribe
    public void onPacketReceive(PacketEvent.Receive event) {
        Satellite.serverManager.onPacketReceived();
        if (event.getPacket() instanceof class_2761)
            Satellite.serverManager.update();
        if (event.getPacket() instanceof class_2658(class_8710 payload)
                && payload instanceof class_8709(String brand)) {
            Satellite.serverManager.setServerBrand(brand);
        }
    }

    @Subscribe
    public void onWorldRender(Render3DEvent event) {
        Satellite.moduleManager.onRender3D(event);
    }

    @Subscribe
    public void onRenderGameOverlayEvent(Render2DEvent event) {
        Satellite.moduleManager.onRender2D(event);
    }

    @Subscribe
    public void onKeyInput(KeyInputEvent event) {
        Satellite.moduleManager.onKeyPressed(event.getKey());
    }

    @Subscribe
    public void onMouseInput(MouseInputEvent event) {
        if (event.getAction() == 1) {
            Satellite.moduleManager.onMouseClicked(event.getButton());
        }
    }

    @Subscribe
    public void onChatSent(ChatEvent event) {
        String message = event.getMessage();
        if (!message.startsWith(Satellite.commandManager.getCommandPrefix())) {
            return;
        }
        event.cancel();
        Satellite.commandManager.onChatSent(message);
    }
}
