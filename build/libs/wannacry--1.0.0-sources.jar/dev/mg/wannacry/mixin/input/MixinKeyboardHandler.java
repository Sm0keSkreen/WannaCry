package dev.mg.wannacry.mixin.input;

import dev.mg.wannacry.event.impl.input.KeyInputEvent;
import net.minecraft.class_11908;
import net.minecraft.class_309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static dev.mg.wannacry.util.traits.Util.EVENT_BUS;

@Mixin(class_309.class)
public class MixinKeyboardHandler {
    @Inject(method = "keyPress", at = @At("TAIL"), cancellable = true)
    private void keyPress(long window, int action, class_11908 input, CallbackInfo ci) {
        if (action != 1) {
            return;
        }

        if (EVENT_BUS.post(new KeyInputEvent(input.comp_4795()))) {
            ci.cancel();
        }
    }
}
