package dev.mg.wannacry.mixin.input;

import dev.mg.wannacry.event.impl.input.MouseInputEvent;
import net.minecraft.class_11910;
import net.minecraft.class_312;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static dev.mg.wannacry.util.traits.Util.EVENT_BUS;

@Mixin(class_312.class)
public class MixinMouseHandler {
    @Inject(method = "onButton", at = @At("HEAD"), cancellable = true)
    private void onButton(long window, class_11910 input, int action, CallbackInfo ci) {
        if (EVENT_BUS.post(new MouseInputEvent(input.comp_4801(), action))) {
            ci.cancel();
        }
    }
}

