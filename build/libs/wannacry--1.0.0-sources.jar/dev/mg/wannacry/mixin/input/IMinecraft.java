package dev.mg.wannacry.mixin.input;

import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_310.class)
public interface IMinecraft {

    @Invoker("startAttack")
    boolean invokeStartAttack();
}
