package dev.mg.wannacry.mixin.render;

import dev.mg.wannacry.features.modules.render.NoRenderModule;
import net.minecraft.class_10017;
import net.minecraft.class_2561;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_897.class)
public class MixinNoRenderNametag<T, S extends class_10017> {

    @Inject(method = "renderNameTagIfPresent", at = @At("HEAD"), cancellable = true, require = 0)
    private void satellite$noNametag(
            S state,
            class_2561 displayName,
            class_4587 poseStack,
            class_4597 bufferSource,
            int packedLight,
            CallbackInfo ci) {
        NoRenderModule nr = NoRenderModule.getInstance();
        if (nr != null && nr.isEnabled() && nr.nametags.getValue()) ci.cancel();
    }
}
