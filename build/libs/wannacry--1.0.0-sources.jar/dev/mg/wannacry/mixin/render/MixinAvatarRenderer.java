package dev.mg.wannacry.mixin.render;

import dev.mg.wannacry.Satellite;
import dev.mg.wannacry.util.models.Angles;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_11890;
import net.minecraft.class_5498;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static dev.mg.wannacry.util.traits.Util.mc;

@Mixin(class_1007.class)
public class MixinAvatarRenderer {
    @Inject(method = "extractRenderState(Lnet/minecraft/world/entity/Avatar;Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;F)V", at = @At("TAIL"))
    private <T extends class_11890> void extractRenderStateHook(T avatar, class_10055 state, float f, CallbackInfo ci) {
        if (mc.field_1724 != avatar) return;

        if (mc.field_1690.method_31044() == class_5498.field_26664) return;

        Angles lerped = Satellite.rotationManager.getLerpRenderSnapshot(f);
        if (lerped == null) return;
        state.field_53448 = lerped.xRot();
        state.field_53447 = 0;
        state.field_53446 = lerped.yRot();
    }
}
