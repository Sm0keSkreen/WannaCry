package dev.mg.wannacry.mixin.render;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import dev.mg.wannacry.ducks.render.IEntityRenderState;
import net.minecraft.class_10017;
import net.minecraft.class_1297;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_898.class)
public class MixinEntityRenderDispatcher {

    @ModifyExpressionValue(
        method = "extractEntity(Lnet/minecraft/world/entity/Entity;F)Lnet/minecraft/client/renderer/entity/state/EntityRenderState;",
        at = @At(value = "INVOKE",
                 target = "Lnet/minecraft/client/renderer/entity/EntityRenderer;createRenderState(Lnet/minecraft/world/entity/Entity;F)Lnet/minecraft/client/renderer/entity/state/EntityRenderState;")
    )
    private <E extends class_1297> class_10017 satellite$setEntity(class_10017 state, E entity, float partialTicks) {
        ((IEntityRenderState) state).satellite$setEntity(entity);
        return state;
    }
}
