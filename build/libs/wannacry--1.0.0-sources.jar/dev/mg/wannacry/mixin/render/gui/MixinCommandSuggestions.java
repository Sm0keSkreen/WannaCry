package dev.mg.wannacry.mixin.render.gui;

import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.ParseResults;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.suggestion.Suggestions;
import dev.mg.wannacry.Satellite;
import dev.mg.wannacry.manager.CommandManager;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.concurrent.CompletableFuture;
import net.minecraft.class_342;
import net.minecraft.class_4717;
import net.minecraft.class_637;

@Mixin(class_4717.class)
public abstract class MixinCommandSuggestions {
    @Shadow
    private class_4717.class_464 suggestions;
    @Shadow
    private @Nullable CompletableFuture<Suggestions> pendingSuggestions;
    @Shadow
    private @Nullable ParseResults<class_637> currentParse;
    @Shadow
    boolean keepSuggestions;
    @Shadow
    @Final
    class_342 input;

    @Shadow
    protected abstract void updateUsageInfo();

    @SuppressWarnings("unchecked")
    @Inject(method = "updateCommandInfo", at = @At("RETURN"))
    public void updateCommandInfo(CallbackInfo ci, @Local StringReader stringReader) {
        if (!stringReader.canRead() || !stringReader.getString().startsWith(Satellite.commandManager.getCommandPrefix())) {
            return;
        }
        stringReader.skip();

        CommandDispatcher<CommandManager> dispatcher = Satellite.commandManager.getDispatcher();
        ParseResults<CommandManager> parse = dispatcher.parse(stringReader, Satellite.commandManager);
        currentParse = (ParseResults<class_637>) (Object) parse;
        if (suggestions == null || !keepSuggestions) {
            pendingSuggestions = dispatcher.getCompletionSuggestions(parse, input.method_1881());
            pendingSuggestions.thenRun(() -> {
                if (pendingSuggestions.isDone()) {
                    updateUsageInfo();
                }
            });
        }
    }
}
