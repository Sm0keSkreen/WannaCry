package dev.mg.wannacry.mixin.render.gui;

import dev.mg.wannacry.event.impl.render.Render2DEvent;
import dev.mg.wannacry.features.modules.render.NoRenderModule;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_3486;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static dev.mg.wannacry.util.traits.Util.EVENT_BUS;
import static dev.mg.wannacry.util.traits.Util.mc;

@Mixin(class_329.class)
public class MixinGui {

    @Inject(method = "render", at = @At("RETURN"))
    public void render(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        boolean debugOpen = mc.field_61504.method_72776();
        if (debugOpen) return;

        Render2DEvent event = new Render2DEvent(context, tickCounter.method_60637(true));
        EVENT_BUS.post(event);
    }

    private static boolean satellite$nr(java.util.function.Function<NoRenderModule, dev.mg.wannacry.features.settings.Setting<Boolean>> getter) {
        NoRenderModule nr = NoRenderModule.getInstance();
        return nr != null && nr.isEnabled() && getter.apply(nr).getValue();
    }

    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void satellite$noCrosshair(class_332 g, class_9779 dt, CallbackInfo ci) {
        if (satellite$nr(nr -> nr.crosshair)) ci.cancel();
    }

    @Inject(method = "renderBossOverlay", at = @At("HEAD"), cancellable = true)
    private void satellite$noBossBar(class_332 g, class_9779 dt, CallbackInfo ci) {
        if (satellite$nr(nr -> nr.bossBar)) ci.cancel();
    }

    @Inject(method = "renderScoreboardSidebar", at = @At("HEAD"), cancellable = true, require = 0)
    private void satellite$noScoreboard(class_332 g, class_9779 dt, CallbackInfo ci) {
        if (satellite$nr(nr -> nr.scoreboard)) ci.cancel();
    }

    @Inject(method = "renderTitle", at = @At("HEAD"), cancellable = true, require = 0)
    private void satellite$noTitle(class_332 g, class_9779 dt, CallbackInfo ci) {
        if (satellite$nr(nr -> nr.title)) ci.cancel();
    }

    @Inject(method = "renderEffects", at = @At("HEAD"), cancellable = true, require = 0)
    private void satellite$noPotionIcons(class_332 g, class_9779 dt, CallbackInfo ci) {
        if (satellite$nr(nr -> nr.potionIcons)) ci.cancel();
    }

    @Inject(method = "renderVignette(Lnet/minecraft/client/gui/GuiGraphics;Lnet/minecraft/world/entity/Entity;)V",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void satellite$noVignette(class_332 g, class_1297 entity, CallbackInfo ci) {
        if (satellite$nr(nr -> nr.vignette)) ci.cancel();
    }

    @Inject(method = "renderSelectedItemName(Lnet/minecraft/client/gui/GuiGraphics;)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void satellite$noHeldItemName(class_332 g, CallbackInfo ci) {
        if (satellite$nr(nr -> nr.heldItemName)) ci.cancel();
    }

    @Inject(method = "renderCameraOverlays", at = @At("HEAD"), cancellable = true, require = 0)
    private void satellite$noCameraOverlays(class_332 g, class_9779 dt, CallbackInfo ci) {
        NoRenderModule nr = NoRenderModule.getInstance();
        if (nr == null || !nr.isEnabled()) return;
        if (mc.field_1724 == null) return;

        class_1657 p = mc.field_1724;

        if (nr.fireOverlay.getValue()        && p.method_5809())                              { ci.cancel(); return; }
        if (nr.liquidOverlay.getValue()       && (p.method_5777(class_3486.field_15517)
                                                || p.method_5777(class_3486.field_15518)))       { ci.cancel(); return; }
        if (nr.portalOverlay.getValue()       && p.method_51848() > 0)               { ci.cancel(); return; }
        if (nr.spyglassOverlay.getValue()     && p.method_31550())                           { ci.cancel(); return; }
        if (nr.pumpkinOverlay.getValue()      && hasPumpkinHelmet(p))                     { ci.cancel(); return; }
        if (nr.powderedSnowOverlay.getValue() && p.field_27857)                        { ci.cancel(); return; }
        if (nr.inWallOverlay.getValue()       && p.method_5757())                            { ci.cancel(); return; }
    }

    private static boolean hasPumpkinHelmet(class_1657 p) {
        net.minecraft.class_1799 helm = p.method_6118(net.minecraft.class_1304.field_6169);
        return !helm.method_7960() && helm.method_31574(net.minecraft.class_1802.field_17519);
    }
}
