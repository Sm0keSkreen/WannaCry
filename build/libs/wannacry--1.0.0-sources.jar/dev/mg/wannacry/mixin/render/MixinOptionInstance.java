package dev.mg.wannacry.mixin.render;

import dev.mg.wannacry.features.modules.render.FullbrightModule;
import net.minecraft.class_310;
import net.minecraft.class_7172;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_7172.class)
public class MixinOptionInstance<T> {

    @SuppressWarnings("unchecked")
    @Inject(method = "get", at = @At("HEAD"), cancellable = true)
    private void satellite$overrideGammaForFullbright(CallbackInfoReturnable<T> cir) {
        FullbrightModule fb = FullbrightModule.getInstance();
        if (fb == null || !fb.isEnabled()) return;

        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1690 == null) return;

        if ((Object) this != mc.field_1690.method_42473()) return;

        cir.setReturnValue((T) (Double) 15.0);
    }
}
