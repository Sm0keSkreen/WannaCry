package dev.mg.wannacry.mixin.render;

import dev.mg.wannacry.ducks.render.IChatComponent;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.List;
import net.minecraft.class_303;
import net.minecraft.class_338;
import net.minecraft.class_7469;

@Mixin(class_338.class)
public abstract class MixinChatComponent implements IChatComponent {
    @Final @Shadow
    private List<class_303> allMessages;

    @Shadow
    private void refreshTrimmedMessages() {}

    @Override
    public void satellite$addMessage(class_303 message) {
        this.allMessages.addFirst(message);
        this.refreshTrimmedMessages();
    }

    @Override
    public void satellite$removeMessage(class_7469 signature) {
        this.allMessages.removeIf(message -> signature.equals(message.comp_915()));
        this.refreshTrimmedMessages();
    }
}
