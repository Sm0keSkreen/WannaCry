package dev.mg.wannacry.mixin.render;

import dev.mg.wannacry.ducks.render.IEntityRenderState;
import net.minecraft.class_10017;
import net.minecraft.class_1297;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(class_10017.class)
public class MixinEntityRenderState implements IEntityRenderState {
    @Unique
    private @Nullable class_1297 satellite$entity;

    @Override
    public @Nullable class_1297 satellite$getEntity() {
        return satellite$entity;
    }

    @Override
    public void satellite$setEntity(class_1297 entity) {
        this.satellite$entity = entity;
    }
}
