package dev.mg.wannacry.mixin.render;

import dev.mg.wannacry.features.modules.render.NoRenderModule;
import net.minecraft.class_10042;
import net.minecraft.class_1309;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_922.class)
public class MixinNoRenderLiving<T extends class_1309, S extends class_10042> {

    @Inject(
        method = "extractRenderState(Lnet/minecraft/world/entity/LivingEntity;" +
                 "Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;F)V",
        at = @At("TAIL"),
        require = 0
    )
    private void satellite$noDeadEntities(T entity, S state, float partialTick, CallbackInfo ci) {
        NoRenderModule nr = NoRenderModule.getInstance();
        if (nr != null && nr.isEnabled() && nr.deadEntities.getValue() && entity.field_6213 > 0) {
            state.field_53449 = 0f;
        }
    }
}
