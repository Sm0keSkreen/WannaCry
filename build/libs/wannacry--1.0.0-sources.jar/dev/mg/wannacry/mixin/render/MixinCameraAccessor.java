package dev.mg.wannacry.mixin.render;

import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_4184.class)
public interface MixinCameraAccessor {
    @Invoker("setRotation")
    void callSetRotation(float yaw, float pitch);
}
