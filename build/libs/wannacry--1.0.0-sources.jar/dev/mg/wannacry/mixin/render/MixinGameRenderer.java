package dev.mg.wannacry.mixin.render;

import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_757.class)
public abstract class MixinGameRenderer {

}
