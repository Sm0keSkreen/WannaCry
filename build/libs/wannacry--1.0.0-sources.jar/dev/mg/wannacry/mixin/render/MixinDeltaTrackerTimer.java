package dev.mg.wannacry.mixin.render;

import dev.mg.wannacry.Satellite;
import net.minecraft.class_9779;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_9779.class_9781.class)
public class MixinDeltaTrackerTimer {
    @Shadow
    private float deltaTicks;

    @Inject(method = "advanceGameTime(J)I", at = @At(value = "FIELD", target = "Lnet/minecraft/client/DeltaTracker$Timer;lastMs:J", opcode = Opcodes.PUTFIELD))
    public void advanceGameTime(long timeMillis, CallbackInfoReturnable<Integer> cir) {
        this.deltaTicks *= Satellite.TIMER;
    }
}
