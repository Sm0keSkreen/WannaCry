package dev.mg.wannacry.mixin.render;

import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import it.unimi.dsi.fastutil.Stack;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.class_11658;
import net.minecraft.class_11659;
import net.minecraft.class_276;
import net.minecraft.class_3695;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_761;
import net.minecraft.class_7833;
import net.minecraft.class_9779;
import net.minecraft.class_9922;
import net.minecraft.class_9925;
import net.minecraft.class_9960;
import dev.mg.wannacry.ducks.render.ILevelRenderer;
import dev.mg.wannacry.event.impl.render.Render3DEvent;
import dev.mg.wannacry.event.impl.render.RenderBlockOutlineEvent;
import dev.mg.wannacry.render.postprocess.SatelliteShaderESP;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static dev.mg.wannacry.util.traits.Util.EVENT_BUS;
import static dev.mg.wannacry.util.traits.Util.mc;

@Mixin(class_761.class)
public abstract class MixinLevelRenderer implements ILevelRenderer {

    @Shadow private class_276 entityOutlineTarget;
    @Shadow @Final private class_9960 targets;

    @Unique private Stack<class_276> satellite$fbStack;
    @Unique private Stack<class_9925<class_276>> satellite$handleStack;

    @Inject(method = "<init>", at = @At("TAIL"))
    private void satellite$init(CallbackInfo ci) {
        satellite$fbStack     = new ObjectArrayList<>();
        satellite$handleStack = new ObjectArrayList<>();
    }

    @Override
    public void satellite$pushEntityOutlineFramebuffer(class_276 fb) {
        satellite$fbStack.push(entityOutlineTarget);
        entityOutlineTarget = fb;

        satellite$handleStack.push(targets.field_53097);
        targets.field_53097 = () -> fb;
    }

    @Override
    public void satellite$popEntityOutlineFramebuffer() {
        entityOutlineTarget   = satellite$fbStack.pop();
        targets.field_53097 = satellite$handleStack.pop();
    }

    @Inject(method = "renderBlockOutline", at = @At("HEAD"), cancellable = true)
    public void satellite$renderBlockOutline(
            class_4597.class_4598 bufferSource,
            class_4587 poseStack, boolean bl,
            class_11658 levelRenderState,
            CallbackInfo ci) {
        if (EVENT_BUS.post(new RenderBlockOutlineEvent())) {
            ci.cancel();
        }
    }

    @Inject(method = "renderLevel", at = @At("RETURN"))
    private void satellite$render3D(
            class_9922 allocator, class_9779 tickCounter,
            boolean renderBlockOutline, class_4184 camera,
            Matrix4f positionMatrix, Matrix4f matrix4f, Matrix4f projectionMatrix,
            GpuBufferSlice fogBuffer, Vector4f fogColor, boolean renderSky,
            CallbackInfo ci, @Local class_3695 profiler) {

        class_4587 stack = new class_4587();
        stack.method_22903();
        stack.method_22907(class_7833.field_40714.rotationDegrees(mc.field_1773.method_19418().method_19329()));
        stack.method_22907(class_7833.field_40716.rotationDegrees(mc.field_1773.method_19418().method_19330() + 180f));

        profiler.method_15396("satellite-render-3d");
        EVENT_BUS.post(new Render3DEvent(stack, tickCounter.method_60637(true)));
        stack.method_22909();
        profiler.method_15407();
    }

    @Inject(method = "renderLevel", at = @At("HEAD"))
    private void satellite$beginRender(
            class_9922 allocator, class_9779 tickCounter,
            boolean renderBlockOutline, class_4184 camera,
            Matrix4f positionMatrix, Matrix4f matrix4f, Matrix4f projectionMatrix,
            GpuBufferSlice fogBuffer, Vector4f fogColor, boolean renderSky,
            CallbackInfo ci) {
        SatelliteShaderESP.INSTANCE.beginRender();
    }

    @Inject(method = "submitEntities", at = @At("TAIL"))
    private void satellite$submitEntities(
            class_4587 poseStack,
            class_11658 levelRenderState,
            class_11659 output,
            CallbackInfo ci) {
        SatelliteShaderESP.INSTANCE.draw(levelRenderState, poseStack);
    }

    @Inject(method = "renderLevel", at = @At("RETURN"))
    private void satellite$drawStorageBlocks(
            class_9922 allocator, class_9779 tickCounter,
            boolean renderBlockOutline, class_4184 camera,
            Matrix4f positionMatrix, Matrix4f matrix4f, Matrix4f projectionMatrix,
            GpuBufferSlice fogBuffer, Vector4f fogColor, boolean renderSky,
            CallbackInfo ci) {
        SatelliteShaderESP.INSTANCE.drawBlocks(new class_4587());
    }

    @Inject(method = "resize", at = @At("HEAD"))
    private void satellite$resize(int width, int height, CallbackInfo ci) {
        SatelliteShaderESP.INSTANCE.onResized(width, height);
    }
}
