package dev.mg.wannacry.mixin.render;

import dev.mg.wannacry.features.modules.render.ViewModelModule;
import net.minecraft.class_11659;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_759;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_759.class)
public class MixinItemInHandRenderer {

    @Unique
    private boolean satellite$pushed = false;

    @Inject(method = "renderItem", at = @At("HEAD"))
    private void satellite$vmHead(
            class_1309 entity,
            class_1799 item,
            class_811 displayContext,
            class_4587 poseStack,
            class_11659 collector,
            int light,
            CallbackInfo ci
    ) {
        satellite$pushed = false;

        class_1268 hand;
        if (displayContext == class_811.field_4322) {
            hand = class_1268.field_5808;
        } else if (displayContext == class_811.field_4321) {
            hand = class_1268.field_5810;
        } else {
            return;
        }

        ViewModelModule m = ViewModelModule.getInstance();
        if (m == null || !m.isEnabled()) return;

        poseStack.method_22903();
        poseStack.method_46416(m.getPosX(hand), m.getPosY(hand), m.getPosZ(hand));
        poseStack.method_22907(class_7833.field_40714.rotationDegrees(m.getRotX(hand)));
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(m.getRotY(hand)));
        poseStack.method_22907(class_7833.field_40718.rotationDegrees(m.getRotZ(hand)));
        poseStack.method_22905(m.getScale(hand), m.getScale(hand), m.getScale(hand));
        satellite$pushed = true;
    }

    @Inject(method = "renderItem", at = @At("RETURN"))
    private void satellite$vmTail(
            class_1309 entity,
            class_1799 item,
            class_811 displayContext,
            class_4587 poseStack,
            class_11659 collector,
            int light,
            CallbackInfo ci
    ) {
        if (satellite$pushed) {
            poseStack.method_22909();
            satellite$pushed = false;
        }
    }
}
