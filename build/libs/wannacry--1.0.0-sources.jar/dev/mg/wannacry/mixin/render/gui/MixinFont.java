package dev.mg.wannacry.mixin.render.gui;

import net.minecraft.class_327;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_327.class)
public interface MixinFont {
    @Accessor("provider")
    class_327.class_11602 getProvider();
}
