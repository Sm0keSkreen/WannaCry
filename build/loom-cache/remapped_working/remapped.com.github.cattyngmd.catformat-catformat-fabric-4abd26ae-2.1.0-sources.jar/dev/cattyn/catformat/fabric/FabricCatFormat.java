package dev.cattyn.catformat.fabric;

import dev.cattyn.catformat.CatFormatImpl;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.MutableComponent;

public class FabricCatFormat extends CatFormatImpl<MutableComponent> {
    public FabricCatFormat() {
        this(true);
    }

    public FabricCatFormat(boolean vanilla) {
        super(new FabricWrapper());
        if (vanilla) {
            addVanilla();
        }
    }

    private void addVanilla() {
        for (ChatFormatting value : ChatFormatting.values()) {
            if (!value.isColor() || value.getColor() == null) {
                continue;
            }
            add(value.getName(), value.getColor());
        }
    }
}
